/**
  ******************************************************************************
  * @file PTM\main.c
  * @brief This file contains the main function for the PTM1 capture input interrupt example.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * MCU 				: HT66F0175/HT66F0185
  * Operating Voltage 	: 5.0v
  * System Clock 		: 8MHz
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

#include "HT8_MCU_IP_SEL.h"

#ifdef DEBUG
/* Debug mode can be enabled by uncommenting "DEBUG" Macro in HT8_MCU_IP_SEL.h */
	#include "HT8_Simulation_UART.h"
#endif

vu8  g_nCaptureFlag;		//capture complete flag
vu16 g_nCapture_Value;		//capture value
vu8  g_nPTM1_CCRP_Time;		//CCRP counter

/**
  * @brief PTM1 capture input interrupt main entry point.
  * @par Parameters:
  * None
  * @retval 
  * None
  */
  
void main()
{
	g_nPTM1_CCRP_Time = 0;

#ifdef	DEBUG
/* Debug mode can be enabled by uncommenting "DEBUG" Macro in HT8_MCU_IP_SEL.h */
	SIMULATION_UART_INIT();/* simulation uart initialization,baud rate set 9600,TX on PC0 */
#endif
	
	/* initialization PTM IP */
	PTM1_Init();

	PTM1_CaptureInputConfig();
	
	PTM1_RISING_EDGE();
		
	MF1F_CLEAR_FLAG();			//clear multi-function 1 interrupt flag
	MF1E_ENABLE();				//enable multi-function 1 interrupt
	
	PTM1_CLEAR_FLAG_A();		//clear CCRA interrupt flag
	PTM1_CLEAR_FLAG_P();		//clear CCRP interrupt flag
	PTM1_CCRA_ISR_ENABLE();		//enable CCRA interrupt
	PTM1_CCRP_ISR_ENABLE();		//enable CCRP interrupt
	EMI_ENABLE();				//enable global interrupt
	GCC_DELAY(2000);			//wait system stable
	PTM1_ENABLE();				//enable PTM1
	
	//system loop
	while(1)
	{
		GCC_CLRWDT();
		if (g_nCaptureFlag == 1)					//capture finished
		{
			g_nCaptureFlag = 0;
		
		#ifdef	DEBUG	
		/* send capture data to PC for debug,Debug mode can be enabled by 
			uncommenting "DEBUG" Macro in HT8_MCU_IP_SEL.h */
			UART_SoftWareSendByte(0xa9);					//send head code
			GCC_DELAY(100);	
			UART_SoftWareSendByte(g_nCapture_Value>>8);		//send capture data high byte by uart
			GCC_DELAY(100);	
			UART_SoftWareSendByte(g_nCapture_Value&0xff);	//send capture data low byte by uart
		#endif
			
			GCC_CLRWDT();
			GCC_DELAY(10000);
			PTM1_ENABLE();			//enable PTM,start next capture
		}
	}
	
}

/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/