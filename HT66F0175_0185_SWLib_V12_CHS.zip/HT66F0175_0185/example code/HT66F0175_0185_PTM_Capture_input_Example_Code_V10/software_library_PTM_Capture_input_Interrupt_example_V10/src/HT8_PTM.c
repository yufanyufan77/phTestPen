/**
  ******************************************************************************
  * @file HT8_PTM.c
  * @brief This file provides all the PTM firmware functions.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

/* Includes ------------------------------------------------------------------*/


#include "HT8_PTM.h"



#ifdef HT66F0175

/**
  * @brief PTM0 initialization function.
  * @param[in] Non.
  * @retval Non.
  */
void PTM0_Init(void)
{
/******************** work mode select ********************/
	#ifdef	PTM0_TIMER_COUNTER_MODE
		_t0m1 = 1; _t0m0 = 1;	//Select PTM0 timer/counter Mode
		
	#elif	PTM0_PWM_OUTPUT_MODE
		_t0m1 = 1; _t0m0 = 0;	
		_t0io1 = 1; _t0io0 = 0;	 //Select PTM0 PWM Output Mode
		_t0cp = 1;
		_pac0 = 0; _pa0 = 0;
		
	#elif	PTM0_SINGLE_PULSE_OUTPUT_MODE
		_t0m1 = 1; _t0m0 = 0;	
		_t0io1 = 1; _t0io0 = 1;	//Select PTM0 Single Pulse Output Mode
		_t0cp = 1;
		_pac0 = 0; _pa0 = 0;
	
	#elif	PTM0_COMPARE_MATCH_MODE	//Select PTM0 Compare Match Output Mode
		_t0m1 = 0; _t0m0 = 0;
		_t0cp = 1;
		_pac0 = 0; _pa0 = 0;
		
	#elif	PTM0_CAPTURE_INPUT_MODE	//Select PTM0 Capture Input Mode
		_t0m1 = 0; _t0m0 = 1;		
	#endif
/**************** end of work mode select ****************/		

/********************* clock select **********************/
	#ifdef	PTM0_FSYS_DIV4
		_t0ck2 = 0; _t0ck1 = 0; _t0ck0 = 0;	//Select PTM0 Counter clock Fsys/4
	
	#elif	PTM0_FSYS
		_t0ck2 = 0; _t0ck1 = 0; _t0ck0 = 1;	//Select PTM0 Counter clock Fsys
	
	#elif	PTM0_FH_DIV16
		_t0ck2 = 0; _t0ck1 = 1; _t0ck0 = 0; //Select PTM0 Counter clock FH/16
		
	#elif	PTM0_FH_DIV64
		_t0ck2 = 0; _t0ck1 = 1; _t0ck0 = 1; //Select PTM0 Counter clock FH/64
		
	#elif	PTM0_FTBC
		_t0ck2 = 1; _t0ck1 = 0; _t0ck0 = 0;	//Select PTM0 Counter clock Ftbc
		
	#elif	PTM0_FH
		_t0ck2 = 1; _t0ck1 = 0; _t0ck0 = 1; //Select PTM0 Counter clock FH
		
	#elif	PTM0_TCK_RISING_EDGE
		_t0ck2 = 1; _t0ck1 = 1; _t0ck0 = 0; //Select PTM0 Counter clock TCKn rising edge clock
		_ace2 = 0; _pbc2 = 1; _pbpu2 = 1;
		
	#elif	PTM0_TCK_FALLING_EDGE
		_t0ck2 = 1; _t0ck1 = 1; _t0ck0 = 1; //Select PTM0 Counter clock TCKn falling edge clock
		_ace2 = 0; _pbc2 = 1; _pbpu2 = 1;
	#endif	
/********************* end of clock select **********************/
		
/************ TMn Counter Clear condition selection *************/	
	#ifdef	PTM0_CCRA_MATCH
		_t0cclr = 1;	//PTM0 Counter Clear condition selection PTM1 Comparator A match		
	#else
		_t0cclr = 0;	//PTM0 Counter Clear condition selection PTM1 Comparator P match	
	#endif
/********* end of TMn Counter Clear condition selection *********/	
}


/**
  * @brief PTM0 PWM configure function.
  * Specify the following parameters in HT8_PTM.h, 
  * 1.TP0 pin Output control
  * 2.TP0 Output polarity control
  * @param[in] Non.
  * @retval Non.
  */
void PTM0_PwmOutputConfig(void)
{	
/************* TP0 Output control **************/		
	#ifdef	PTM0_ACTIVE_LOW
		_t0oc = 0;					//active low
	#else
		_t0oc = 1;					//active high
	#endif
/********* end of TP0 Output control **********/	
		
/******** TP0 Output polarity control ********/
	#ifdef	PTM0_NON_INVERTED
		_t0pol = 0;					//no inverted
	#else
		_t0pol = 1;					//inverted
	#endif
/******** TP0 Output polarity control ********/	
}


/**
  * @brief PTM0 PWM update function.
  * @param[in] CCRA value.
  * @param[in] CCRP value.
  * @retval Non.
  */
void PTM0_PwmUpdate(u16 TempCCRA,u16 TempCCRP)
{
	_tm0al = TempCCRA & 0x00ff;	//
	_tm0ah = TempCCRA >> 8;		//
	_tm0rpl = TempCCRP & 0x00ff;	//
	_tm0rph = TempCCRP >> 8;
}


/**
  * @brief PTM0 SinglePulse configure function.
  * Specify the following parameters in HT8_PTM.h, 
  * 1.TP0 pin Output control
  * 2.TP0 Output polarity control
  * 3.TCK0 trigger control
  * @param[in] Non.
  * @retval Non.
  */
void PTM0_SinglePulseOutputConfig(void)
{
/************* TP0 Output control **************/		
	#ifdef	PTM0_ACTIVE_LOW
		_t0oc = 0;					//active low
	#else
		_t0oc = 1;					//active high
	#endif
/********* end of TP0 Output control **********/	
		
/******** TP0 Output polarity control ********/
	#ifdef	PTM0_NON_INVERTED
		_t0pol = 0;					//no inverted
	#else
		_t0pol = 1;					//inverted
	#endif
/******** TP0 Output polarity control ********/	

/******** TCK0 trigger control *****/
	#ifdef	PTM0_TCK0_TRIG_ENABLE			
		_ace2 = 0; _pbc2 = 1; _pbpu2 = 1;					
	#endif
/*** end of TCK0 trigger control ***/
}


/**
  * @brief PTM0 SinglePulse update function.
  * @param[in] CCRA value.
  * @retval Non.
  */
void PTM0_SinglePulseUpdate(u16 TempCCRA)
{
	_tm0al = TempCCRA & 0x00ff;	//
	_tm0ah = TempCCRA >> 8;		//
}


/**
  * @brief PTM0 timer/counter mode period config function.
  * @param[in] period value,
  * select CCRA_MATCH,the value is 0~1024;
  * overflow time=TempPeriod * Tclock,
  * select CCRP_MATCH,the value is 0~1024.
  * overflow time=TempPeriod * Tclock, 
  * @retval None.
  */
void PTM0_CounterModeConfig(u16 TempPeriod)
{
#ifdef	PTM0_CCRA_MATCH
	_tm0al = TempPeriod & 0x00ff;	//
	_tm0ah = TempPeriod >> 8;		//
#else	
	_tm0rpl = TempPeriod & 0x00ff;	//
	_tm0rph = TempPeriod >> 8;		//
#endif		
}


/**
  * @brief PTM0 compare match output config function,
  * Specify the following parameters in HT8_PTM.h, 
  * 1.TP0 pin output function select
  * 2.TP0 pin Output initial status control
  * 3.TP0 Output polarity control
  * @param[in] None.
  * @retval None.
  */
void PTM0_CompareMatchOutputConfig()
{
/********** Select TP0 pin output function **********/	
	#ifdef	PTM0_NO_CHANGE
		_t0io1 = 0; _t0io0 = 0;	//
	
	#elif	PTM0_OUTPUT_LOW
		_t0io1 = 0; _t0io0 = 1;	//
	
	#elif	PTM0_OUTPUT_HIGH
		_t0io1 = 1; _t0io0 = 0;	//
	
	#elif	PTM0_OUTPUT_TOGGLE
		_t0io1 = 1; _t0io0 = 1;	//
	#endif
/********** Select TP0 pin output function **********/	

/***** TP0 Output initialization status control *****/			
	#ifdef	PTM0_INITIAL_LOW
		_t0oc = 0;				//
	#else
		_t0oc = 1;	
	#endif			
/** end of TP0 Output initialization status control */		

/*********** TP0 Output polarity control ************/	
	#ifdef	PTM0_NON_INVERTED
		_t0pol = 0;				//
	#else
		_t0pol = 1;				//
	#endif
/******* end of TP0 Output polarity control ********/
}


/**
  * @brief PTM0 compare match output update function,
  * @param[in] MatchTime value,
  * select CCRA_MATCH,the value is 0~1024;
  * match time=TempMatchTime * Tclock,
  * select CCRP_MATCH,the value is 0~1024.
  * match time=TempMatchTime * Tclock, 
  * @retval None.
  */
void PTM0_CompareMatchOutputUpdate(u16 TempMatchTime)
{
#ifdef	PTM0_CCRA_MATCH
	_tm0al = TempMatchTime & 0x00ff;	//
	_tm0ah = TempMatchTime >> 8;		//
#else	
	_tm0al = 1;	//
	_tm0ah = 0;		//
	_tm0rpl = TempMatchTime & 0x00ff;	//
	_tm0rph = TempMatchTime >> 8;
#endif	
}


/**
  * @brief PTM0 Capture Input config function,
  * Specify the following parameters in HT8_PTM.h, 
  *	Select Trigger Pin  
  * @param[in] None.
  * @retval None.
  */
void PTM0_CaptureInputConfig()
{
/******** Select Trigger Pin function ********/	
	#ifdef	PTM0_CAPTURE_TP0
		_t0cp = 1; _t0capts = 0;	//
		_pac0 = 1; _papu0 = 1;
	
	#elif	PTM0_CAPTURE_TCK0
		_ace2 = 0; _t0capts = 1;	//
		_pbc2 = 1; _pbpu2 = 1;
	#endif
/******** Select Trigger Pin function ********/	
}

#endif





/**
  * @brief PTM1 initialization function.
  * @param[in] Non.
  * @retval Non.
  */
void PTM1_Init(void)
{
/******************** work mode select ********************/
	#ifdef	PTM1_TIMER_COUNTER_MODE
		_t1m1 = 1; _t1m0 = 1;	//Select PTM1 timer/counter Mode
		
	#elif	PTM1_PWM_OUTPUT_MODE
		_t1m1 = 1; _t1m0 = 0;	
		_t1io1 = 1; _t1io0 = 0; //Select PTM1 PWM Output Mode
		_ace6 = 0; _t1cp = 1;
		_pac7 = 0; _pa7 = 0;
		
	#elif	PTM1_SINGLE_PULSE_OUTPUT_MODE
		_t1m1 = 1; _t1m0 = 0;	
		_t1io1 = 1; _t1io0 = 1;	//Select PTM1 Single Pulse Output Mode
		_ace6 = 0; _t1cp = 1;
		_pac7 = 0; _pa7 = 0;
	
	#elif	PTM1_COMPARE_MATCH_MODE	//Select PTM1 Compare Match Output Mode
		_t1m1 = 0; _t1m0 = 0;
		_ace6 = 0; _t1cp = 1;
		_pac7 = 0; _pa7 = 0;
		
	#elif	PTM1_CAPTURE_INPUT_MODE	//Select PTM1 Capture Input Mode
		_t1m1 = 0; _t1m0 = 1;		
	#endif
/**************** end of work mode select ****************/		

/********************* clock select **********************/
	#ifdef	PTM1_FSYS_DIV4
		_t1ck2 = 0; _t1ck1 = 0; _t1ck0 = 0;	//Select PTM1 Counter clock Fsys/4
	
	#elif	PTM1_FSYS
		_t1ck2 = 0; _t1ck1 = 0; _t1ck0 = 1;	//Select PTM1 Counter clock Fsys
	
	#elif	PTM1_FH_DIV16
		_t1ck2 = 0; _t1ck1 = 1; _t1ck0 = 0; //Select PTM1 Counter clock FH/16
		
	#elif	PTM1_FH_DIV64
		_t1ck2 = 0; _t1ck1 = 1; _t1ck0 = 1; //Select PTM1 Counter clock FH/64
		
	#elif	PTM1_FTBC
		_t1ck2 = 1; _t1ck1 = 0; _t1ck0 = 0;	//Select PTM1 Counter clock Ftbc
		
	#elif	PTM1_FH
		_t1ck2 = 1; _t1ck1 = 0; _t1ck0 = 1; //Select PTM1 Counter clock FH
		
	#elif	PTM1_TCK_RISING_EDGE
		_t1ck2 = 1; _t1ck1 = 1; _t1ck0 = 0; //Select PTM1 Counter clock TCKn rising edge clock
		_ace3 = 0; _pac4 = 1; _papu4 = 1
		
	#elif	PTM1_TCK_FALLING_EDGE
		_t1ck2 = 1; _t1ck1 = 1; _t1ck0 = 1; //Select PTM1 Counter clock TCKn falling edge clock
		_ace3 = 0; _pac4 = 1; _papu4 = 1
	#endif	
/********************* end of clock select **********************/
		
/************ TMn Counter Clear condition selection *************/	
	#ifdef	PTM1_CCRA_MATCH
		_t1cclr = 1;	//PTM1 Counter Clear condition selection PTM1 Comparator A match		
	#else
		_t1cclr = 0;	//PTM1 Counter Clear condition selection PTM1 Comparator P match	
	#endif
/********* end of TMn Counter Clear condition selection *********/	
}


/**
  * @brief PTM1 PWM configure function.
  * Specify the following parameters in HT8_PTM.h, 
  * 1.TP1 pin Output control
  * 2.TP1 Output polarity control
  * @param[in] Non.
  * @retval Non.
  */
void PTM1_PwmOutputConfig(void)
{
/************* TP1 Output control **************/		
	#ifdef	PTM1_ACTIVE_LOW
		_t1oc = 0;					//active low
	#else
		_t1oc = 1;					//active high
	#endif
/********* end of TP1 Output control **********/	
		
/******** TP1 Output polarity control ********/
	#ifdef	PTM1_NON_INVERTED
		_t1pol = 0;					//no inverted
	#else
		_t1pol = 1;					//inverted
	#endif
/******** TP1 Output polarity control ********/	
}


/**
  * @brief PTM1 PWM update function.
  * @param[in] CCRA value.
  * @param[in] CCRP value.
  * @retval Non.
  */
void PTM1_PwmUpdate(u16 TempCCRA,u16 TempCCRP)
{
	_tm1al = TempCCRA & 0x00ff;	//
	_tm1ah = TempCCRA >> 8;		//
	_tm1rpl = TempCCRP & 0x00ff;	//
	_tm1rph = TempCCRP >> 8;
}


/**
  * @brief PTM1 SinglePulse configure function.
  * Specify the following parameters in HT8_PTM.h, 
  * 1.TP1 pin Output control
  * 2.TP1 Output polarity control
  * 3.TCK1 trigger control
  * @param[in] Non.
  * @retval Non.
  */
void PTM1_SinglePulseOutputConfig(void)
{
/************* TP1 Output control **************/		
	#ifdef	PTM1_ACTIVE_LOW
		_t1oc = 0;					//active low
	#else
		_t1oc = 1;					//active high
	#endif
/********* end of TP1 Output control **********/	
		
/******** TP1 Output polarity control ********/
	#ifdef	PTM1_NON_INVERTED
		_t1pol = 0;					//no inverted
	#else
		_t1pol = 1;					//inverted
	#endif
/******** TP1 Output polarity control ********/	

/******** TCK1 trigger control *****/
	#ifdef	PTM1_TCK1_TRIG_ENABLE			
		_ace3 = 0; _pac4 = 1; _papu4 = 1					
	#endif
/*** end of TCK1 trigger control ***/
}


/**
  * @brief PTM1 SinglePulse update function.
  * @param[in] CCRA value.
  * @retval Non.
  */
void PTM1_SinglePulseUpdate(u16 TempCCRA)
{
	_tm1al = TempCCRA & 0x00ff;	//
	_tm1ah = TempCCRA >> 8;		//
}


/**
  * @brief PTM1 timer/counter mode period config function.
  * @param[in] period value,
  * select CCRA_MATCH,the value is 0~1024;
  * overflow time=TempPeriod * Tclock,
  * select CCRP_MATCH,the value is 0~1024.
  * overflow time=TempPeriod * Tclock, 
  * @retval None.
  */
void PTM1_CounterModeConfig(u16 TempPeriod)
{
#ifdef	PTM1_CCRA_MATCH
	_tm1al = TempPeriod & 0x00ff;	//
	_tm1ah = TempPeriod >> 8;		//
#else	
	_tm1rpl = TempPeriod & 0x00ff;	//
	_tm1rph = TempPeriod >> 8;		//
#endif		
}


/**
  * @brief PTM1 compare match output config function,
  * Specify the following parameters in HT8_PTM.h, 
  * 1.TP1 pin output function select
  * 2.TP1 pin Output initial status control
  * 3.TP1 Output polarity control
  * @param[in] None.
  * @retval None.
  */
void PTM1_CompareMatchOutputConfig()
{
/********** Select TP1 pin output function **********/	
	#ifdef	PTM1_NO_CHANGE
		_t1io1 = 0; _t1io0 = 0;	//
	
	#elif	PTM1_OUTPUT_LOW
		_t1io1 = 0; _t1io0 = 1;	//
	
	#elif	PTM1_OUTPUT_HIGH
		_t1io1 = 1; _t1io0 = 0;	//
	
	#elif	PTM1_OUTPUT_TOGGLE
		_t1io1 = 1; _t1io0 = 1;	//
	#endif
/********** Select TP1 pin output function **********/	

/***** TP1 Output initialization status control *****/			
	#ifdef	PTM1_INITIAL_LOW
		_t1oc = 0;				//
	#else
		_t1oc = 1;	
	#endif			
/** end of TP1 Output initialization status control */		

/*********** TP1 Output polarity control ************/	
	#ifdef	PTM1_NON_INVERTED
		_t1pol = 0;				//
	#else
		_t1pol = 1;				//
	#endif
/******* end of TP1 Output polarity control ********/
}


/**
  * @brief PTM1 compare match output update function,
  * @param[in] MatchTime value,
  * select CCRA_MATCH,the value is 0~1024;
  * match time=TempMatchTime * Tclock,
  * select CCRP_MATCH,the value is 0~1024.
  * match time=TempMatchTime * Tclock, 
  * @retval None.
  */
void PTM1_CompareMatchOutputUpdate(u16 TempMatchTime)
{
#ifdef	PTM1_CCRA_MATCH
	_tm1al = TempMatchTime & 0x00ff;	//
	_tm1ah = TempMatchTime >> 8;		//
#else	
	_tm1al = 1;	//
	_tm1ah = 0;		//
	_tm1rpl = TempMatchTime & 0x00ff;	//
	_tm1rph = TempMatchTime >> 8;
#endif	
}


/**
  * @brief PTM1 Capture Input config function,
  * Specify the following parameters in HT8_PTM.h, 
  *	Select Trigger Pin  
  * @param[in] None.
  * @retval None.
  */
void PTM1_CaptureInputConfig()
{
/******** Select Trigger Pin function ********/	
	#ifdef	PTM1_CAPTURE_TP1
		_ace6 = 0; _t1cp = 1; _t1capts = 0;	//
		_pac7 = 1; _papu7 = 1;
	
	#elif	PTM1_CAPTURE_TCK1
		_ace3 = 0; _t1capts = 1;	//
		_pac4 = 1; _papu4 = 1
	#endif
/******** Select Trigger Pin function ********/	
}

/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/