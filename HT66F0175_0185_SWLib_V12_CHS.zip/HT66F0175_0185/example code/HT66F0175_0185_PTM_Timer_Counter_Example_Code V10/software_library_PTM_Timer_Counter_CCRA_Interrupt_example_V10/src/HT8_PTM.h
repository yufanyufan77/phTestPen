/**
  ******************************************************************************
  * @file HT8_PTM.h
  * @brief The header file of the PTM library.
  * @author Holtek Semiconductor inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef _PTM_H_
#define _PTM_H_

#include "HT8_MCU_IP_SEL.h"

#ifdef HT66F0175
#define	PTM0_ENABLE()			(_t0on = 1)
#define	PTM0_DISABLE()			(_t0on = 0)
#define	PTM0_CCRA_ISR_ENABLE()	(_t0ae = 1)
#define	PTM0_CCRA_ISR_DISABLE()	(_t0ae = 0)
#define PTM0_SET_FLAG_A()		(_t0af = 1)
#define PTM0_CLEAR_FLAG_A()		(_t0af = 0)
#define	PTM0_CCRP_ISR_ENABLE()	(_t0pe = 1)
#define	PTM0_CCRP_ISR_DISABLE()	(_t0pe = 0)
#define PTM0_SET_FLAG_P()		(_t0pf = 1)
#define PTM0_CLEAR_FLAG_P()		(_t0pf = 0)
#define	PTM0_PAUSE()			(_t0pau = 1)
#define	PTM0_RUN()				(_t0pau = 0)
#define	PTM0_GET_CCRA_FLAG()	_t0af
#define	PTM0_GET_CCRP_FLAG()	_t0pf

#define PTM0_RISING_EDGE() 		  	_t0io1 = 0; _t0io0 = 0	/* Input capture at rising edge */
#define PTM0_FALLING_EDGE()		  	_t0io1 = 0; _t0io0 = 1 	/* Input capture at falling edge */
#define PTM0_RISING_FALLING_EDGE() 	_t0io1 = 1; _t0io0 = 0 	/* Input capture at rising/falling edge */
#define PTM0_CAPTURE_DISABLE()	  	_t0io1 = 1; _t0io0 = 1 	/* Input capture Disable */

#endif


#define	PTM1_ENABLE()			(_t1on = 1)
#define	PTM1_DISABLE()			(_t1on = 0)
#define	PTM1_CCRA_ISR_ENABLE()	(_t1ae = 1)
#define	PTM1_CCRA_ISR_DISABLE()	(_t1ae = 0)
#define PTM1_SET_FLAG_A()		(_t1af = 1)
#define PTM1_CLEAR_FLAG_A()		(_t1af = 0)
#define	PTM1_CCRP_ISR_ENABLE()	(_t1pe = 1)
#define	PTM1_CCRP_ISR_DISABLE()	(_t1pe = 0)
#define PTM1_SET_FLAG_P()		(_t1pf = 1)
#define PTM1_CLEAR_FLAG_P()		(_t1pf = 0)
#define	PTM1_PAUSE()			(_t1pau = 1)
#define	PTM1_RUN()				(_t1pau = 0)
#define	PTM1_GET_CCRA_FLAG()	_t1af
#define	PTM1_GET_CCRP_FLAG()	_t1pf

#define PTM1_RISING_EDGE() 		  	_t1io1 = 0; _t1io0 = 0	/* Input capture at rising edge */
#define PTM1_FALLING_EDGE()		  	_t1io1 = 0; _t1io0 = 1 	/* Input capture at falling edge */
#define PTM1_RISING_FALLING_EDGE() 	_t1io1 = 1; _t1io0 = 0 	/* Input capture at rising/falling edge */
#define PTM1_CAPTURE_DISABLE()	  	_t1io1 = 1; _t1io0 = 1 	/* Input capture Disable */


/******** PTM work mode select ********/
	#ifdef HT66F0175
//	#define	PTM0_TIMER_COUNTER_MODE			1
	#define	PTM0_PWM_OUTPUT_MODE			1	
//	#define	PTM0_COMPARE_MATCH_MODE			1
//	#define	PTM0_CAPTURE_INPUT_MODE			1
//	#define	PTM0_SINGLE_PULSE_OUTPUT_MODE	1
	#endif

	#define	PTM1_TIMER_COUNTER_MODE			1
//	#define	PTM1_PWM_OUTPUT_MODE			1	
//	#define	PTM1_COMPARE_MATCH_MODE			1
//	#define	PTM1_CAPTURE_INPUT_MODE			1
//	#define	PTM1_SINGLE_PULSE_OUTPUT_MODE	1

/**** end of PTM work mode select *****/


/************* clock select **************/
	#ifdef HT66F0175
	#define		PTM0_FSYS_DIV4			1
//	#define		PTM0_FSYS				1
//	#define		PTM0_FH_DIV16			1
//	#define		PTM0_FH_DIV64			1
//	#define		PTM0_FTBC				1
//	#define		PTM0_FH					1
//	#define		PTM0_TCK_RISING_EDGE	1
//	#define		PTM0_TCK_FALLING_EDGE	1
	#endif
	
	#define		PTM1_FSYS_DIV4			1
//	#define		PTM1_FSYS				1
//	#define		PTM1_FH_DIV16			1
//	#define		PTM1_FH_DIV64			1
//	#define		PTM1_FTBC				1
//	#define		PTM1_FH					1
//	#define		PTM1_TCK_RISING_EDGE	1
//	#define		PTM1_TCK_FALLING_EDGE	1
/********* end of clock select *********/
	
/** TMn Counter Clear condition selection **/
	#ifdef HT66F0175
	#define		PTM0_CCRA_MATCH			1
//	#define		PTM0_CCRP_MATCH			1
	#endif
	
	#define		PTM1_CCRA_MATCH			1
//	#define		PTM1_CCRP_MATCH			1	
/* end of TMn Counter Clear condition selection */

	
/****** PWM OUTPUT MODE setting ******/

#ifdef	PTM0_PWM_OUTPUT_MODE		
/* TP0 Output control */
//	#define		PTM0_ACTIVE_LOW				1
	#define		PTM0_ACTIVE_HIGH			1
/* end of TP0 Output control */
	
/***** TP0 Output polarity control *****/
	#define		PTM0_NON_INVERTED			1
//	#define		PTM0_INVERTED				1
/* end of TP0 Output polarity control */
#endif

	
#ifdef	PTM1_PWM_OUTPUT_MODE		
/* TP1 Output control */
//	#define		PTM1_ACTIVE_LOW	 			1
	#define		PTM1_ACTIVE_HIGH			1
/* end of TP1 Output control */
	
/***** TP1 Output polarity control *****/
	#define		PTM1_NON_INVERTED			1
//	#define		PTM1_INVERTED				1
/* end of TP1 Output polarity control */

#endif

/* end of PWM OUTPUT MODE setting */
///////////////////////////////////////////////////////


/****** SINGLE PULSE OUTPUT MODE setting ******/

#ifdef	PTM0_SINGLE_PULSE_OUTPUT_MODE					
/* TP0 Output control */
//	#define		PTM0_ACTIVE_LOW				1
	#define		PTM0_ACTIVE_HIGH			1
/* end of TP0 Output control */
	
/***** TP0 Output polarity control *****/
	#define		PTM0_NON_INVERTED			1
//	#define		PTM0_INVERTED				1
/* end of TP0 Output polarity control */

/***** TCK0 trigger control *****/
	#define		PTM0_TCK0_TRIG_ENABLE		1
//	#define		PTM0_TCK0_TRIG_DISABLE		1
/* end of TCK0 trigger control */
#endif

		
#ifdef	PTM1_SINGLE_PULSE_OUTPUT_MODE		
/* TP1 Output control */
//	#define		PTM1_ACTIVE_LOW				1
	#define		PTM1_ACTIVE_HIGH			1
/* end of TP1 Output control */
	
/***** TP1 Output polarity control *****/
	#define		PTM1_NON_INVERTED			1
//	#define		PTM1_INVERTED				1
/* end of TP1 Output polarity control */	

/***** TCK1 trigger control *****/
	#define		PTM1_TCK1_TRIG_ENABLE		1
//	#define		PTM1_TCK1_TRIG_DISABLE		1
/* end of TCK1 trigger control */		
#endif

/* end of SINGLE PULSE OUTPUT MODE setting */
//////////////////////////////////////////////////////


/* TIMER COUNTER MODE setting */

#ifdef	PTM0_TIMER_COUNTER_MODE

	#define	PTM0_GET_COUNTER_VALUE()	(_tm0dh<<8 | _tm0dl)
	
#endif


#ifdef	PTM1_TIMER_COUNTER_MODE

	#define	PTM1_GET_COUNTER_VALUE()	(_tm1dh<<8 | _tm1dl)

#endif
/* end of TIMER COUNTER MODE setting */
///////////////////////////////////////////////////////	


/* COMPARE MATCH MODE setting */

#ifdef	PTM0_COMPARE_MATCH_MODE
/* Select TP0 pin output function */
//	#define		PTM0_NO_CHANGE				1	/* No change */
//	#define		PTM0_OUTPUT_LOW				1	/* Output low */
//	#define		PTM0_OUTPUT_HIGH			1	/* Output high */
	#define		PTM0_OUTPUT_TOGGLE			1	/* Toggle output */
/* end of Select TP0 pin output function */
		
/* TP0 Output initialization status control */
	#define		PTM0_INITIAL_LOW			1	/* Initial low */
//	#define		PTM0_INITIAL_HIGH			1	/* Initial high */
/* end of TP0 Output control */
	
/***** TP0 Output polarity control *****/
	#define		PTM0_NON_INVERTED			1
//	#define		PTM0_INVERTED				1
/* end of TP0 Output polarity control */
#endif
	

#ifdef	PTM1_COMPARE_MATCH_MODE	
	/* Select TP1 pin output function */
//	#define		PTM1_NO_CHANGE				1	/* No change */
//	#define		PTM1_OUTPUT_LOW				1	/* Output low */
//	#define		PTM1_OUTPUT_HIGH			1	/* Output high */
	#define		PTM1_OUTPUT_TOGGLE			1	/* Toggle output */
/* end of Select TP1 pin output function */
	
/* TP1 Output initialization status control */
	#define		PTM1_INITIAL_LOW			1	/* Initial low */
//	#define		PTM1_INITIAL_HIGH			1	/* Initial high */
/* end of TP1 Output control */
	
/***** TP1 Output polarity control *****/
	#define		PTM1_NON_INVERTED			1
//	#define		PTM1_INVERTED				1
/* end of TP1 Output polarity control */	
#endif

/* end of COMPARE MATCH MODE setting */
//////////////////////////////////////////////////////


/* CAPTURE INPUT MODE setting */

#ifdef	PTM0_CAPTURE_INPUT_MODE	
/* Select Trigger Pin function */
//	#define		PTM0_CAPTURE_TP0			1	/* From TPn pin */
	#define		PTM0_CAPTURE_TCK0			1	/* From TCKn pin */
/* end of Select Trigger Pin function */

/* GET CAPTURE VALUE function */
	#define	PTM0_GET_CAPTURE_VALUE()	(_tm0ah<<8 | _tm0al)
#endif
	
	
#ifdef	PTM1_CAPTURE_INPUT_MODE	
/* Select Trigger Pin function */
	#define		PTM1_CAPTURE_TP1			1	/* From TPn pin */
//	#define		PTM1_CAPTURE_TCK1			1	/* From TCKn pin */
/* end of Select Trigger Pin function */


/* GET CAPTURE VALUE function */
	#define	PTM1_GET_CAPTURE_VALUE()	(_tm1ah<<8 | _tm1al)

#endif
/* end of CAPTURE INPUT MODE setting */
////////////////////////////////////////////




#ifdef HT66F0175
void PTM0_Init(void);
void PTM0_PwmOutputConfig(void);
void PTM0_PwmUpdate(u16 TempCCRA,u16 TempCCRP);
void PTM0_SinglePulseOutputConfig(void);
void PTM0_SinglePulseUpdate(u16 TempCCRA);
void PTM0_CounterModeConfig(u16 TempPeriod);
void PTM0_CompareMatchOutputConfig();
void PTM0_CompareMatchOutputUpdate(u16 TempMatchTime);
void PTM0_CaptureInputConfig();
#endif

void PTM1_Init(void);
void PTM1_PwmOutputConfig(void);
void PTM1_PwmUpdate(u16 TempCCRA,u16 TempCCRP);
void PTM1_SinglePulseOutputConfig(void);
void PTM1_SinglePulseUpdate(u16 TempCCRA);
void PTM1_CounterModeConfig(u16 TempPeriod);
void PTM1_CompareMatchOutputConfig();
void PTM1_CompareMatchOutputUpdate(u16 TempMatchTime);
void PTM1_CaptureInputConfig();

#endif
/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/