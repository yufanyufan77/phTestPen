/**
  ******************************************************************************
  * @file HT8_SPI_Slave.h
  * @brief The header file of the SPI slave library.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef _SIM_SPI_Slave_H_
#define _SIM_SPI_Slave_H_

#include "HT8_MCU_IP_SEL.h"

#define	SPI_ENABLE()				_simen=1	//SPI enable
#define	SPI_DISABLE()				_simen=0	//SPI disable
#define	SPI_CS_ENABLE()				_csen=1		//SPI SCS pin enable
#define	SPI_CS_DISABLE()			_csen=0		//SPI SCS pin disable

#define	SPI_ISR_ENABLE()			_sime=1		//SPI interrupt enable
#define	SPI_ISR_DISABLE()			_sime=0		//SPI interrupt disable

#define	SPI_FLAG					_simf		//SPI interrupt flag	
#define	SPI_WRITE_COLLISION_FLAG	_wcol		//SPI write collision flag	
#define	SPI_TRX_FLAG				_trf		//SPI Transmit/Receive complete flag



/******** SPI SCK clock active edge type selection *****/
//	#define SCK_HIGH_RISING_EDGE		1	 //SCK is high base level and data capture at SCK rising edge
	#define SCK_HIGH_FALLING_EDGE		1	 //SCK is high base level and data capture at SCK falling edge
//	#define SCK_LOW_FALLING_EDGE		1	 //SCK is low base level and data capture at SCK falling edge
//	#define SCK_LOW_RISING_EDGE			1	 //SCK is low base level and data capture at SCK rising edge
/* end of SPI SCK clock active edge type selection */


/*********** SPI data shift order **************/
//	#define LSB_FIRST			1
	#define MSB_FIRST			1
/* end of SPI data shift order */


#ifdef HT66F0185
/************ HT66F0185 SDO pin-remapping selection ************/
	#define SDO_PC3				1
//	#define SDO_PA1				1
//	#define SDO_PC2				1
/* end of SDO pin-remapping selection */
		
/************ HT66F0185 SDI pin-remapping selection ************/
	#define SDI_PC4				1	
//	#define SDI_PA3				1
/* SDI pin-remapping selection */
	
/*********** HT66F0185 SCK pin-remapping selection *************/
	#define SCK_PC5				1
//	#define SCK_PB6				1
/* end of SCK pin-remapping selection */

/************ HT66F0185 SCS pin-remapping selection ************/
	#define SCS_PC6				1	
//	#define SCS_PB5				1
/*end of SCS pin-remapping selection */

#else
/************ HT66F0175 SDO pin-remapping selection ************/
	#define SDO_PC2				1
//	#define SDO_PA1				1
/* end of SDO pin-remapping selection */
		
/************ HT66F0175 SDI pin-remapping selection ************/
	#define SDI_PC3				1	
//	#define SDI_PA3				1
/* SDI pin-remapping selection */
	
/*********** HT66F0175 SCK pin-remapping selection *************/
	#define SCK_PC4				1
//	#define SCK_PB6				1
/* end of SCK pin-remapping selection */

/************ HT66F0185 SCS pin-remapping selection ************/
	#define SCS_PA1				1	
//	#define SCS_PB5				1
/*end of SCS pin-remapping selection */

#endif


void SPI_Slave_Init(void);
void SPI_PinConfig(void);

#endif

/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/