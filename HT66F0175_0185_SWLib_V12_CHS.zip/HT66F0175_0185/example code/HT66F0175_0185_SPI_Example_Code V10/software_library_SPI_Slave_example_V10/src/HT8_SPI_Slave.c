/**
  ******************************************************************************
  * @file HT8_SPI_Slave.c
  * @brief This file provides all the SPI slave firmware functions.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

/* Includes ------------------------------------------------------------------*/

#include "HT8_SPI_Slave.h"

extern vu8 g_nTx_Buf,g_nRx_Buf;	//SPI transmit/receive buff
extern vu8 g_nRx_Flag;			//SPI receive complete flag


/**
  * @brief SPI initialization function.
  * @param[in] Non.
  * @retval Non.
  */
void SPI_Slave_Init(void)
{
	_sim2=1; _sim1=0; _sim0=1; //Select SPI slave mode	
				    	
//SPI SCK clock active edge type selection
#ifdef SCK_HIGH_RISING_EDGE
	_ckpolb=0; _ckeg=0;	 //SCK is high base level and data capture at SCK rising edge
	
#elif  SCK_HIGH_FALLING_EDGE 
	_ckpolb=0; _ckeg=1; //SCK is high base level and data capture at SCK falling edge
	
#elif SCK_LOW_FALLING_EDGE	
	_ckpolb=1; _ckeg=0; //SCK is low base level and data capture at SCK falling edge
	
#elif SCK_LOW_RISING_EDGE 
	_ckpolb=1; _ckeg=1;	//SCK is low base level and data capture at SCK rising edge
#endif	
		
//SPI data shift order
#ifdef	LSB_FIRST
	_mls=0;	//LSB first
#elif	MSB_FIRST
	_mls=1;	//MSB first    
#endif	
	
	SPI_PinConfig();	//
	SPI_CS_ENABLE();	//SPI SCS pin control enable
	SPI_ENABLE();
	do
	{
		SPI_WRITE_COLLISION_FLAG = 0;
		_simd = g_nTx_Buf;			//writer first transmit byte to simd
		_nop();	
     	_nop();	
     	_nop();	
     	_nop();	
		GCC_CLRWDT();	
	}while(SPI_WRITE_COLLISION_FLAG == 1); //ceck Write Collision			
	
}


void SPI_PinConfig(void)
{
#ifdef HT66F0185	//HT66F0185 pin share setting	
	/*SDO pin-remapping selection*/
	#ifdef SDO_PC3
		_sdops1 = 0; _sdops0 = 0;
		
	#elif SDO_PA1
		_sdops1 = 0; _sdops0 = 1;
		
	#elif SDO_PC2
		_sdops1 = 1; _sdops0 = 1;
	#endif
		
	/*SDI pin-remapping selection*/
	#ifdef SDI_PC4
		_sdi_sdaps = 0;
		
	#elif SDI_PA3
		_sdi_sdaps = 1;
		_cos = 1;
	#endif	
		
	/*SCK pin-remapping selection*/
	#ifdef SCK_PC5
		_sck_sclps = 0;
		
	#elif SCK_PB6
		_sck_sclps = 1;
		_csel = 0;
	#endif
	
	/*SCS pin-remapping selection	*/
	#ifdef SCS_PC6
		_scsbps=0;
		
	#elif SCS_PB5
		_scsbps = 1;
		_csel = 0;
	#endif
#else				//HT66F0175 pin share setting
	/*SDO pin-remapping selection*/
	#ifdef SDO_PC2
		_sdops = 0; 
		
	#elif SDO_PA1
		_sdops = 1;
	#endif
		
	/*SDI pin-remapping selection*/
	#ifdef SDI_PC3
		_sdi_sdaps = 0;
		
	#elif SDI_PA3
		_sdi_sdaps = 1;
	#endif	
		
	/*SCK pin-remapping selection*/
	#ifdef SCK_PC4
		_sck_sclps = 0;
		
	#elif SCK_PB6
		_sck_sclps = 1;
	#endif
	
	/*SCS pin-remapping selection	*/
	#ifdef SCS_PA1
		_scsbps=0;
		
	#elif SCS_PB5
		_scsbps = 1;
	#endif
	
#endif
}



/**
  * @brief SIM(I2C or SPI) Interruption routine.
  * @par Parameters:
  * None
  * @retval
  * None
  */
void __attribute((interrupt(0x28))) SIM_ISR(void)
{
	SPI_FLAG = 0;
	SPI_ISR_DISABLE();	
	g_nTx_Buf++;			//data+1 for next transmit

	do
	{
		SPI_WRITE_COLLISION_FLAG = 0;
		_simd = g_nTx_Buf;					//write data to simd,the data will be transmit next interrupt
		GCC_CLRWDT();	
	}while(SPI_WRITE_COLLISION_FLAG==1); 	//ceck Write Collision
	
	g_nRx_Buf = _simd;	//receive data
	SPI_TRX_FLAG = 0;
	SPI_ISR_ENABLE();
	g_nRx_Flag = 1;		//set receive finished flag
}

/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/