/**
  ******************************************************************************
  * @file HT8_UART.c
  * @brief This file provides all the UART firmware functions.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

#include "HT8_UART.h"

vu16 g_nUART_ISR_Value;	//uart receive buff
vu8 UART_RX_FLAG;		//uart receive success flag




/**
  * @brief UART initialization function.
  * @param[in] uart baud rate.
  * It can be 0x00~0xff.
  * @retval None
  */
/************************************************************
PS:If Fsys = 16MHZ, BaudRate input values reference table.
   -------------------------------------------------------------------
   | Baud Rate values | 4800 | 9600 | 19200 | 38400 | 57600 |115200|
   -------------------------------------------------------------------
   | High speed Mode  | 0xcf | 0x67 |  0x33 |  0x19 |  0x10 | 0x08 |
   | error rate       | 0.16%| 0.16%| 0.16% | 0.16% |  2.1% |-3.5% |
   -------------------------------------------------------------------
   | Low speed Mode   | 0x33 | 0x19 | 0x0c  |  ---- |  ---- |    
   | error rate       | 0.16%| 0.16%| 0.16% |  ---- |  ---- |
   -------------------------------------------------------------------  

PS:If Fsys = 12MHZ, BaudRate input values reference table.
   -------------------------------------------------------------------
   | Baud Rate values | 4800 | 9600 | 19200 | 38400 | 57600 |115200|
   -------------------------------------------------------------------
   | High speed Mode  | 0x9b | 0x4d |  0x26 |  0x13 |  0x0c | ---- |
   | error rate       | 0.16%| 0.16%| 0.16% | -2.3% | 0.16% | ---- |
   -------------------------------------------------------------------
   | Low speed Mode   | 0x26 | 0x13 | 0x09  |  0x04 |  ---- | ---- |  
   | error rate       | 0.16%|-2.3% |-2.3%  | -2.3% |  ---- | ---- |
   -------------------------------------------------------------------  

PS:If Fsys = 8MHZ, BaudRate input values reference table.
   -------------------------------------------------------------------
   | Baud Rate values | 4800 | 9600 | 19200 | 38400 | 57600 | 
   -------------------------------------------------------------------
   | High speed Mode  | 0x67 | 0x33 |  0x19 |  0x0c |  0x08 | 
   | error rate       | 0.16%| 0.16%| 0.16% | 0.16% | -3.5% |
   -------------------------------------------------------------------
   | Low speed Mode   | 0x19 | 0x0c |  ---- |  ---- |  ---- |    
   | error rate       | 0.16%| 0.16%| 
   -------------------------------------------------------------------  
**********************************************************************/
void UART_Init(u8 BaudRate)
{
	tx_c = 1;
	tx_pu = 1;		//TX pin pull high
	rx_c = 1;
	rx_pu = 1;		//RX pin pull high

	/**************************************/	

	#ifdef	TX_PD2
		_pd2  = 1;
		_txps = 0; 
	#endif	/*TX pin select pd2*/

	#ifdef	RX_PD1
		
		_rxps = 0; 
	#endif	/*RX pin select pd1*/
	
	#ifdef	TX_PB3
		_pb3  = 1;
		_ace7 = 0;
		_txps = 1; 
	#endif	/*TX pin select pb3*/

	#ifdef	RX_PB4
		_rxps = 1; 
	#endif	/*RX pin select pb4*/
	
	/**************************************/	
		
	#ifdef	EVENPR_MODE
		_pren = 1; _prt = 0; 	/*Even parity Mode config*/
	
	#elif	ODDPR_MODE
		_pren = 1; _prt = 1;	/*Odd parity Mode config*/
		
	#else
		_pren = 0;	
	#endif
	
	/**************************************/	
	
	#ifdef	NINE_BIT_MODE
		_bno = 1;
	#else	/* 9 Number of data bits*/
		_bno = 0;
	#endif	/* 8 Number of data bits*/

	/**************************************/
	
	#ifdef	HIGH_MODE
		_brgh = 1;
	#endif	/*High speed Mode*/
	
	#ifdef	LOW_MODE
		_brgh = 0;
	#endif	/*Low speed Mode*/

	/**************************************/

	#ifdef	TWO_STOPS_MODE
		_stops = 1;
	#else	/* 2 Number of stop bits*/
		_stops = 0;
	#endif	/* 1 Number of stop bits*/

	/**************************************/

	_brg = BaudRate;	//Baud Rate values config
}

/**********************************************************************/

/************************* UART transmit data **************************/



/**
  * @brief UART transmit function.
  * @par:transmit data.
  * @retval
  * None
  */
void UART_Transmit(u16 data)
{
	/* Initialization */
	_tx8 = 0;		


	/* waitting UART transmitter free */
	while(!_tidle)		
	{
		_nop();
	}					
	/* end */
	
	/**************************************/
	
	/* Write data to UART transmitter */
	#ifdef	NINE_BIT_MODE	
	_txr_rxr = data;
	if( data > 255)
	{
		_tx8 = 1;
	}	 
	#else
	_txr_rxr = data;
	#endif
	/* Write end */

	/**************************************/

	/* Waitting UART transmit data finished*/
	while(!_txif)
	{
		_nop();
	}
	/* transmit finished */
}


/**
  * @brief UART receive Interruption routine,only for HT66F0185.
  * @par Parameters:
  * None
  * @retval
  * None
  */
void __attribute((interrupt(0x2C))) UART_ISR(void)
{
	g_nUART_ISR_Value = 0;	//clear receive value
	UART_RX_FLAG =0;		//clear receive finished flag		
/**************************************/
	
	/* parity error flag*/
	#ifdef	EVENPR_MODE	
		if(_perr)
		{
			/* Even parity error,user can set error flag in here */
			_perr = 0;
			_rxif = 0;
			_urf = 0;
			return;
		}
	#endif	

	#ifdef	ODDPR_MODE
		if(_perr)
		{
			/* Odd parity error,user can set error flag in here */
			_perr = 0;
			_rxif = 0;
			_urf = 0;
			return;
		}
	#endif
	/* end */
			
/**************************************/	
			
	/* noise error flag*/	
	#ifdef	NF_MODE
		if(_nf)
		{
			/* Noise error,user can set error flag in here */
			_nf = 0;
			_rxif = 0;
			_urf = 0;
			return;
		}
	#endif
	/* end */
		
/**************************************/
		
	/* framing error flag*/	
	#ifdef	FERR_MODE
		if(_ferr)
		{
			/* Framing error,user can set error flag in here */
			_ferr = 0;
			_rxif = 0;
			_urf = 0;
			return;
		}
	#endif
	/* end */
			
/**************************************/
			
	/* Overrun error flag */
	#ifdef	OERR_MODE
		if(_oerr)
		{
			/* Overrun error,user can set error flag in here */
			_oerr = 0;
			_rxif = 0;
			_urf = 0;
			return;
		}
	#endif
	/* end */
				
/**************************************/
	
	/* receive data success */
	#ifdef	NINE_BIT_MODE
		if(_rx8==1)
		{
			g_nUART_ISR_Value = _txr_rxr + 256;
		}
		else
		g_nUART_ISR_Value = _txr_rxr;
	#else
		g_nUART_ISR_Value = _txr_rxr;
	#endif
	/* end */
		
		
	UART_RX_FLAG = 1;
	_rxif = 0;	
	_urf = 0;//Clear interrupt flag
}

/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/