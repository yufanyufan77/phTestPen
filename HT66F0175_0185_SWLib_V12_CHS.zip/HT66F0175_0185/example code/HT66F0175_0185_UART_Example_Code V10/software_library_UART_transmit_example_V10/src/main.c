/**
  ******************************************************************************
  * @file HT8_UART\main.c
  * @brief This file contains the main function for the UART transmit example.
  * @author Holtek Semiconductor Inc.
  * @version V1.2.0
  * @date 2018-12-20
  ******************************************************************************
  * MCU 				: HT66F0185
  * Operating Voltage 	: 5.0v
  * System Clock 		: 8MHz
  ******************************************************************************
    * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

#include "HT8_MCU_IP_SEL.h"

vu8 g_nUART_TxData = 0;


/**
  * @brief UART transmit main entry point.
  * @par Parameters:
  * None
  * @retval 
  * None
  */
void main()
{	
	_wdtc = 0x57;			//Watchdog config
	
/************************************************************
PS:If Fsys = 16MHZ, BaudRate input values reference table.
   -------------------------------------------------------------------
   | Baud Rate values | 4800 | 9600 | 19200 | 38400 | 57600 |115200|
   -------------------------------------------------------------------
   | High speed Mode  | 0xcf | 0x67 |  0x33 |  0x19 |  0x10 | 0x08 |
   | error rate       | 0.16%| 0.16%| 0.16% | 0.16% |  2.1% |-3.5% |
   -------------------------------------------------------------------
   | Low speed Mode   | 0x33 | 0x19 | 0x0c  |  ---- |  ---- |    
   | error rate       | 0.16%| 0.16%| 0.16% |  ---- |  ---- |
   -------------------------------------------------------------------  

PS:If Fsys = 12MHZ, BaudRate input values reference table.
   -------------------------------------------------------------------
   | Baud Rate values | 4800 | 9600 | 19200 | 38400 | 57600 |115200|
   -------------------------------------------------------------------
   | High speed Mode  | 0x9b | 0x4d |  0x26 |  0x13 |  0x0c | ---- |
   | error rate       | 0.16%| 0.16%| 0.16% | -2.3% | 0.16% | ---- |
   -------------------------------------------------------------------
   | Low speed Mode   | 0x26 | 0x13 | 0x09  |  0x04 |  ---- | ---- |  
   | error rate       | 0.16%|-2.3% |-2.3%  | -2.3% |  ---- | ---- |
   -------------------------------------------------------------------  

PS:If Fsys = 8MHZ, BaudRate input values reference table.
   -------------------------------------------------------------------
   | Baud Rate values | 4800 | 9600 | 19200 | 38400 | 57600 | 
   -------------------------------------------------------------------
   | High speed Mode  | 0x67 | 0x33 |  0x19 |  0x0c |  0x08 | 
   | error rate       | 0.16%| 0.16%| 0.16% | 0.16% | -3.5% |
   -------------------------------------------------------------------
   | Low speed Mode   | 0x19 | 0x0c |  ---- |  ---- |  ---- |    
   | error rate       | 0.16%| 0.16%| 
   -------------------------------------------------------------------  
*************************************************************/	
	UART_Init(0x33);		//UART config high speed,baud rate 9600,TX on PD2
	_clrwdt();				//Clear Watchdog
	UART_RX_FLAG = 0;
	UART_ENABLE();			//UART funtion enable
	UART_TX_ENABLE();		//UART Transmitter enable
	
	while(1)
	{				
		UART_Transmit(g_nUART_TxData);			//UART send data
		g_nUART_TxData++;
		GCC_CLRWDT();							//Clear Watchdog
		GCC_DELAY(3000);
		GCC_CLRWDT();							//Clear Watchdog
	}	
}

/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/

