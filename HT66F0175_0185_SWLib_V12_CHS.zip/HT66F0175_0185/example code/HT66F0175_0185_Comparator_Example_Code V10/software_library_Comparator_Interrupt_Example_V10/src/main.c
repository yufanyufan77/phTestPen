/**
  ******************************************************************************
  * @file HT8_COMP\main.c
  * @brief This file contains the main function for the comparator example.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * MCU 				: HT66F0185
  * Operating Voltage 	: 5.0v
  * System Clock 		: 8MHz
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

#include "HT8_MCU_IP_SEL.h"


/**
  * @brief comparator main entry point.
  * @par Parameters:
  * None
  * @retval 
  * None
  */
void main()
{
	_pcc0 = 0;			//set pc0 output mode
	_pc0 = 1;			//test IO
	
	COMP_Init();		//comparator initialization function
	COMP_ENABLE();		//enable comparator
	COMP_CLEAR_FLAG();	//clear comparator interrupt flag
	COMP_ISR_ENABLE();	//enable comparator interrupt
	EMI_ENABLE();		//enable global interrupt
	
	GCC_DELAY(2000);	//wait system stable
	
	//system loop
	while(1)
	{
	/* comparator interrupt(0x08) in the HT8_it.c,When the
	   comparator interrupt is generated,the PC0 io will be
	   flip in comparator interrupt routine */
		GCC_CLRWDT();	//clear watch dog counter
	}
}

/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/