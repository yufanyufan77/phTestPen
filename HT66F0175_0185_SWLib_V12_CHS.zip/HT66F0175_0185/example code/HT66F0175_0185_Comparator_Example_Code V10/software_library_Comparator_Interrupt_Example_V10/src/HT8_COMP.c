/**
  ******************************************************************************
  * @file HT8_COMP.c
  * @brief This file provides all the Comparator initialization firmware functions.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "HT8_COMP.h"



/**
  * @brief comparator initialization function, only for HT66F0185.
  * @par Parameters:
  * None
  * @retval
  * None
  */

void COMP_Init()
{
	_csel = 1;	//comparator input pin enable
	
/********** comparator output polarity select **********/		
	#ifdef	COMP_OUTPUT_INVERTED
		_cpol = 1;
	#else
		_cpol = 0;
	#endif
/****** end of comparator output polarity select *******/	

/************ comparator output pin control ************/		
	#ifdef	COMP_OUTPUT_ENABLE
		_cos = 0;
	#else
		_cos = 1;
	#endif	
/********* end of comparator output pin control ********/	

/******** Comparator Hysteresis function control *******/		
	#ifdef	COMP_HYSTERESIS_ENABLE
		_chyen = 1;
	#else
		_chyen = 0;
	#endif	
/**** end of Comparator Hysteresis function control ****/
	
/** Comparator output interrupt trigger edge select  ***/	
	#ifdef	RISING_EDGE
		_cmpeg1 = 0; _cmpeg0 = 0;
		
	#elif	FALLING_EDGE
		_cmpeg1 = 0; _cmpeg0 = 1;
		
	#elif	BOTH_EDGE
		_cmpeg1 = 1; _cmpeg0 = 1;
	#endif
/* end of Comparator output interrupt trigger edge select*/

}

/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/