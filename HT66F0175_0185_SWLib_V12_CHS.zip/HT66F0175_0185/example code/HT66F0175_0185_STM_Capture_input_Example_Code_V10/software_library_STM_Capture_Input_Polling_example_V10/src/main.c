/**
  ******************************************************************************
  * @file STM\main.c
  * @brief This file contains the main function for the STM capture input polling example.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * MCU 				: HT66F0185
  * Operating Voltage 	: 5.0v
  * System Clock 		: 8MHz
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

#include "HT8_MCU_IP_SEL.h"

#ifdef DEBUG
/* Debug mode can be enabled by uncommenting "DEBUG" Macro in HT8_MCU_IP_SEL.h */
	#include "HT8_Simulation_UART.h"
#endif

vu16 g_nCapture_Value;				//pulse width
vu16 g_nCapture_rising_Value;		//rising edge data
vu16 g_nCapture_falling_Value;		//falling edge data

/**
  * @brief STM capture input polling main entry point.
  * @par Parameters:
  * None
  * @retval 
  * None
  */
void main()
{
#ifdef	DEBUG
/* Debug mode can be enabled by uncommenting "DEBUG" Macro in HT8_MCU_IP_SEL.h */	
	SIMULATION_UART_INIT();/* simulation UART initialization,baud rate set 9600,TX on PC0 */
#endif	
	
	/* initialization STM IP */
	STM_Init();
	
	STM_CAPTURE_RISING_EDGE();	//capture rising edge	
	
	STM_CLEAR_FLAG_A();			//clear STM CCRA interrupt flag
	STM_CLEAR_FLAG_P();			//clear STM CCRP interrupt flag

	GCC_DELAY(2000);			//wait system stable
	STM_ENABLE();				//enable STM

	//system loop
	while(1)
	{
		GCC_CLRWDT();
		
		if( 1 == STM_GET_CCRA_FLAG() )
		{
			STM_CLEAR_FLAG_A();
			
			if( _t0io1 == 0 && _t0io0 == 0 )
			{
				g_nCapture_rising_Value = STM_GET_CAPTURE_VALUE();	//capture rising data
				STM_CAPTURE_FALLING_EDGE();
			}
			
			else if( _t0io1 == 0 && _t0io0 == 1 )
			{
				
				g_nCapture_falling_Value = STM_GET_CAPTURE_VALUE();	//capture falling data

				if (g_nCapture_falling_Value >= g_nCapture_rising_Value)
				g_nCapture_Value = g_nCapture_falling_Value - g_nCapture_rising_Value;//calculate pulse width
				else
				g_nCapture_Value = 65536 - g_nCapture_rising_Value + g_nCapture_falling_Value;
				g_nCapture_Value>>=1;		//division 2,unit is us
				STM_CAPTURE_RISING_EDGE();
				STM_DISABLE();				//disable STM
				
			#ifdef	DEBUG
			/* send capture data to PC for debug,Debug mode can be enabled by 
				uncommenting "DEBUG" Macro in HT8_MCU_IP_SEL.h */
				UART_SoftWareSendByte(0xa9);				
				GCC_CLRWDT();
				GCC_DELAY(100);
				UART_SoftWareSendByte(g_nCapture_Value >> 8);		//send high byte of pulse width to PC by uart
				GCC_DELAY(100);
				UART_SoftWareSendByte(g_nCapture_Value & 0x00ff);	//send low byte of pulse width to PC by uart
				GCC_CLRWDT();
				GCC_DELAY(10000);
			#endif	
				
				g_nCapture_Value = 0;
				
				STM_CLEAR_FLAG_A();
				STM_ENABLE();						//STM enable,start next capture
			}
	
		}
	}
}

/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/