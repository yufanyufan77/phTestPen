/**
  ******************************************************************************
  * @file HT8_CTM.c
  * @brief This file provides all the CTM firmware functions.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

/* Includes ------------------------------------------------------------------*/

#include	"CTM.h"


/**
  * @brief CTM initialization function.
  * 2ms even.
  * @param[in] none.
  * @retval  none.
  */
void CTMInit(void)
{
	_tm2c0 = 0b00000000;	//f=fh/4=8/4MHz=2MHz,t=1/f=1/2us
	_tm2c1 = 0b11000001;	//select timer/counter mode,CCRA match clear counter
	_tm2al = 4000 & 0xff;	//CCRA low byte,16bit timer,time out 4000*0.5us = 2000us = 2ms
	_tm2ah = 4000 >> 8;		//CCRA high byte
	_mf1e = 1;				//enable multi-function1 interrupt
	_mf1f = 0;				//clear  multi-function1 interrupt flag
	_t2ae = 1;				//enable CTM CCRA interrupt
	_t2af = 0;				//clear CTM CCRA interrupt flag
	_t2on = 1;
}



/**
  * @brief CTM CCRA interrupt routine.
  * 2ms even,use for LCD scan and update.
  * @param[in] none.
  * @retval  none.
  */
void __attribute((interrupt(0x10))) CTM_DSP_ISR(void)
{
	if (_t2af)					//CTM 2ms time out flag
	{	
		_t2af = 0;
		
		LcdComScan();			//LCD COM scan
		LcdSegScan();			//LCD SEG scan
		
		g_u8ScanCoun++; 		//next bit
		if (g_u8ScanCoun > 7) 
		{
			g_u8ScanCoun = 0; 	//LCD scan finished
			CopyRam(); 			//copy display data to DspRam
		}
	}	
}

/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/