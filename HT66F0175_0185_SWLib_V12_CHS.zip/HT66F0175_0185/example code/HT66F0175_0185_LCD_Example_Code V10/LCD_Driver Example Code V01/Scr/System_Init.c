/**
  ******************************************************************************
  * @file System_Init.c
  * @brief This file provides all the system initialization firmware functions.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

/* Includes ------------------------------------------------------------------*/

#include	"System_Init.h"

/**
  * @brief clear RAM function.
  * @param[in] none.
  * @retval  none.
  */
void ClrRam(void)   //Clear RAM 
{
	_bp=0;
	_mp1=0x80;
	for(_tblp=0;_tblp<128;_tblp++)	//clear bank0
	{
		_iar1=0;
		_mp1++;	
	}
	_bp=1;
	_mp1=0x80;
	for(_tblp=0;_tblp<128;_tblp++)	//clear bank1
	{
		_iar1=0;
		_mp1++;	
	}
	_bp=0;
}


/**
  * @brief system initialization function.
  * @param[in] none.
  * @retval  none.
  */
void SysInit(void)
{
	_smod = 0b00000011;		//_idlen=1,_hlclk=1;set Fsys = FH
	_ctrl = 0;
	_wdtc = 0b01010111;		//enable WDT 
	_cpc  = 0b00001000;
	
	_sledc0 = 0b11111111;	//source current select level3(max)
	_sledc1 = 0b00111111;
	_ifs   = 0;				//pin shared set default value
	_tmpc  = 0;				//disble timer output
	_simc0 = 0b11100000;	//disable SPI IIC
	_simc1 = 0b10000001;
	_acerl = 0;           	//disable ADC

	/* IO Port initialize */
	_pac = 0xff;
	_pbc = 0xff;
	_pcc = 0xff;
	_pdc = 0xff;
}

/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/