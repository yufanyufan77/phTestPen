/**
  ******************************************************************************
  * @file HT8_I2C_Slave.c
  * @brief This file provides all the I2C slave firmware functions.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

/* Includes ------------------------------------------------------------------*/


#include "HT8_I2C_Slave.h"

volatile _I2C_Flag		I2C_Flag;

vu8 u8_Commend = 0;

void I2C_Slave_Init()
{
#ifdef HT66F0185	//HT66F0185 pin share setting	
	#ifdef	SDA_PC4	
		_sdi_sdaps = 0;					//SDA on PC4
	#else
		_cos = 1;						//disable comparator output function
		_sdi_sdaps = 1;					//SDA on PA3
	#endif
	
	#ifdef	SCL_PC5	
		_sck_sclps = 0;					//SCL on PC5
	#else
		_csel = 0;						//disable comparator input function
		_sck_sclps = 1;					//SCL on PB6
	#endif
#else				//HT66F0175 pin share setting
	#ifdef	SDA_PC3	
		_sdi_sdaps = 0;					//SDA on PC3
	#else
//		_cos = 1;						//disable comparator output function
		_sdi_sdaps = 1;					//SDA on PA3
	#endif
	
	#ifdef	SCL_PC4	
		_sck_sclps = 0;					//SCL on PC4
	#else
//		_csel = 0;						//disable comparator input function
		_sck_sclps = 1;					//SCL on PB6
	#endif


#endif	

#ifdef	I2C_DEBOUNCE_DISABLE
	_simdeb1 = 0; _simdeb0 = 0;		//no debounce time

#elif	I2C_DEBOUNCE_2_FSYS
	_simdeb1 = 0; _simdeb0 = 1;		//debounce time 2 Fsys
#else
	_simdeb1 = 1; _simdeb0 = 0;		//debounce time 4 Fsys
#endif	

	I2C_Flag.Byte = 0;				//clear flag
	_sima = I2C_DEVICEADDR;   		//I2C slave address 0x72
	_sim2 =1; _sim1 = 1; _sim0 = 0;	//select I2C slave mode
}


/**
  * @brief I2C Time-out update function,
  * @param[in] Time-out value,
  * the value is 0~63.
  * time= (timeout+1) * Tsub * 32, 
  * @retval None.
  */
void I2C_Timeout_Update(u8 timeout)
{
	_simtoc &= 0xc0;
	timeout &= 0x3f;
	_simtoc |= timeout;
}


void __attribute((interrupt(0x28))) I2C_ISR(void)  //I2C interrupt service routine
{
	
	volatile	u8 I2C_Temp;
	static		u8 CheckSum = 0;	
	static		u8 I2C_Rx_Step = 0;
	static		u8 I2C_Tx_Step = 0;
	static		u8 I2C_ReadData[4];

	if (!_simtof)  			//not I2C timeout
	{
		if (1 == _haas)   	//_haas=1,address match trig interrupt	
		{
			if (1 == _srw)  //srw=1:slave in transfer mode
			{
				if(COMMEND_WORK_ID == u8_Commend )  //communication is OK 
				{
					_htx = 1;					
					_simd = I2C_TX_Data[0]; 		//write data to _simd to release SCL line
					CheckSum = I2C_TX_Data[0];		//checksum
					I2C_Tx_Step = 0;
				}
			}
			else  //srw=0:slave in receive mode
			{
				_htx  = 0;
				_txak = 0;
				_acc  = _simd;		//dummy read from _simd to release SCL line
				I2C_Flag.Bit.Fg_COMMEND_RD = 1;
			}
		}
		else	//_haas=0,data trig interrupt
		{
			if (1 == _htx)  		//htx=1:slave in write state;
			{
				if (1 == _rxak)  	//rxak=1:master stop receiving next byte,master releases scl bus
				{
					_htx  = 0; 
					_txak = 0;
					_acc  = _simd;	//dummy read from _simd to release SCL line
				}	
				else 				//rxak=0:master wants to receive next byte;
				{
					//clear receive step
					I2C_Rx_Step = 0;
					if(COMMEND_WORK_ID == u8_Commend )  //communication is OK  
					{
						switch(I2C_Tx_Step++)
						{
							//----------------------------		
							case 0:	
									_simd = I2C_TX_Data[1];		//send data
									CheckSum = CheckSum + I2C_TX_Data[1]; 
									break;
							//----------------------------		
							case 1:										
									_simd = I2C_TX_Data[2];		//send data
									CheckSum = CheckSum + I2C_TX_Data[2];
									break;

							//----------------------------
							case 2:	
									if(1 == I2C_Flag.Bit.Fg_CheckSum_Er)//communication error
									{
										I2C_Flag.Bit.Fg_CheckSum_Er = 0;
										_simd = CheckSum + ERROR_HEAD;  //send error CheckSum to master	
									}
									else 								//communication is OK
									{
										_simd = CheckSum;				//send CheckSum
										GCC_NOP();
									}
									I2C_Tx_Step = 0 ;
									break;
							//----------------------------
							default:
									I2C_Tx_Step = 0;
									break;
						}
					
					}
				}
			}
			else  //htx=0:slave in read state
			{
				if (1 == I2C_Flag.Bit.Fg_COMMEND_RD)	//receive command
				{
					I2C_Temp = _simd;					//read command byte
					if(COMMEND_WORK_ID == I2C_Temp )	//communication is OK  
					{
						I2C_Flag.Bit.Fg_COMMEND_RD = 0;
						u8_Commend = I2C_Temp;
					}
					I2C_Tx_Step = 0;	
					I2C_Rx_Step = 0;
				}
				else  //receive data
				{
					if (COMMEND_WORK_ID == u8_Commend)	//communication is OK  	
					{
						switch(I2C_Rx_Step++)
						{
							case 0:						
								I2C_ReadData[0] = _simd;//receive first byte data
								_txak = 0;		
							break;
							//----------------------------
							case 1:						
								I2C_ReadData[1] = _simd;//receive second byte data
								_txak = 0;
							break;
							//----------------------------
							case 2:						
								I2C_ReadData[2] = _simd;//receive second byte data
								_txak = 0;
							break;
							
							
							//----------------------------
							case 3:						//receive third byte data
								I2C_ReadData[3] = _simd;
								u8_Commend = 0;			//receive all of data,clear command byte
								CheckSum = I2C_ReadData[0] + I2C_ReadData[1] + I2C_ReadData[2];
								
								if ((I2C_ReadData[3] == CheckSum))  		//Check_Sum OK
								{
									_txak = 1;    							//respond NO ACK
									I2C_ReceiveBuff[0] = I2C_ReadData[0];	//first byte
									I2C_ReceiveBuff[1] = I2C_ReadData[1];	//second byte
									I2C_ReceiveBuff[2] = I2C_ReadData[2];	//third byte
									I2C_ReceiveBuff[3] = I2C_ReadData[3];	//forth byte,CheckSum
									I2C_TX_Data[0] = I2C_ReadData[0];	//I2C slave will send the receive data
									I2C_TX_Data[1] = I2C_ReadData[1];	//I2C slave will send the receive data
									I2C_TX_Data[2] = I2C_ReadData[2];	//I2C slave will send the receive data
									I2C_TX_Data[3] = I2C_ReadData[3];	//I2C slave will send the receive data
									I2C_Flag.Bit.Fg_CheckSum_Er = 0;		//clear checksum error flag
									I2C_Flag.Bit.RX_Flag = 1;				//receive success and complete flag
								}
								else
								{
									_txak = 1;								//NO ACK
									I2C_Flag.Bit.Fg_CheckSum_Er = 1;		//CheckSum error flag
								}
								I2C_Rx_Step = 0;
							break;
							//----------------------------
							default:
								I2C_Rx_Step = 0;
							break;
						}
					}
				}
			}
		}	
	}	
	else	//I2C communication timeout
	{
		_simtof  = 0;
		_simtoen = 1;
		/* user define,such as set a I2C timeout flag */
	}
	I2C_CLEAR_FLAG();  //clear I2C interrupt flag
}


/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/