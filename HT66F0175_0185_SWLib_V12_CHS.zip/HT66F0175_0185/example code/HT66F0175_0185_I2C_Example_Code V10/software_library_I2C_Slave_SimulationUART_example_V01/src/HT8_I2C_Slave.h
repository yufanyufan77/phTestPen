/**
  ******************************************************************************
  * @file HT8_I2C_Slave.h
  * @brief The header file of the I2C Slave library.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef _HT8_I2C_h_
#define	_HT8_I2C_h_

#include "HT8_MCU_IP_SEL.h"

#define	I2C_DEVICEADDR		0X72	//II2 Slave addr

#define	I2C_ENABLE()		_simen = 1	//enable SIM(I2C) IP
#define	I2C_DISABLE()		_simen = 0	//disable SIM(I2C) IP
#define	I2C_ISR_ENABLE()	_sime  = 1	//enable SIM(I2C) interrupt
#define	I2C_ISR_DISABLE()	_sime  = 0	//disable SIM(I2C) interrupt
#define	I2C_SET_FLAG()		_simf  = 1	//set SIM(I2C) interrupt flag
#define	I2C_CLEAR_FLAG()	_simf  = 0	//clear SIM(I2C) interrupt flag

#define	I2CTO_ENABLE()		_simtoen = 1	//enable I2C Time-out control
#define	I2CTO_DISABLE()		_simtoen = 0	//disable I2C Time-out control

#ifdef HT66F0185
/************** HT66F0185 I2C SDA pin select **************/
	#define SDA_PC4					1	//set pc4 pin as I2C SDA,default
//	#define SDA_PA3					1	//set pa3 pin as I2C SDA
/********** end of I2C SDA pin select ***********/
	
/************** I2C SCL pin select **************/	
	#define SCL_PC5					1	//set pc5 pin as I2C SCL,default
//	#define SCL_PB6					1	//set pb6 pin as I2C SCL
/********** end of HT66F0185 I2C SCL pin select ***********/

#else
/************** HT66F0175 I2C SDA pin select **************/
	#define SDA_PC3					1	//set pc4 pin as I2C SDA
//	#define SDA_PA3					1	//set pa3 pin as I2C SDA,default
/********** end of I2C SDA pin select ***********/
	
/************** I2C SCL pin select **************/	
	#define SCL_PC4					1	//set pc5 pin as I2C SCL
//	#define SCL_PB6					1	//set pb6 pin as I2C SCL,default
/********** end of HT66F0175 I2C SCL pin select ***********/

#endif

/*********** I2C debounce time select ***********/
//	#define	I2C_DEBOUNCE_DISABLE	1	//I2C no debounce
	#define	I2C_DEBOUNCE_2_FSYS		1	//I2C debounce 2 Fsys,default
//	#define	I2C_DEBOUNCE_4_FSYS		1	//I2C debounce 4 Fsys
/******* end of I2C debounce time select ********/



#define	DATA_NUM			4		//receive and transmit bytes
#define	ERROR_HEAD  		3		//

#define	COMMEND_WORK_ID		0X11	//command Byte

typedef union
{
	struct
	{      
		u8	RX_Flag		 	:1;
		u8	Fg_COMMEND_RD	:1;
		u8	Fg_CheckSum_Er	:1;
		u8	nc3				:1;
		u8	nc4				:1;
		u8	nc5				:1;
		u8	nc6				:2;
	}Bit;    
	u8 Byte;    
}_I2C_Flag;


extern volatile _I2C_Flag	I2C_Flag;
extern vu8 I2C_ReceiveBuff[];
extern vu8	I2C_TX_Data[];

void I2C_Slave_Init();
void I2C_Timeout_Update(u8 timeout);

#endif

/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/