/**
  ******************************************************************************
  * @file I2C_Master\main.c
  * @brief This file contains the main function for the I2C Master example.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2018-12-20
  ******************************************************************************
  * MCU 				: HT66F0175/HT66F0185
  * Operating Voltage 	: 5.0v
  * System Clock 		: 8MHz
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

#include "HT8_MCU_IP_SEL.h"

#ifdef	DEBUG
/* Debug mode can be enabled by uncommenting "DEBUG" Macro in HT8_MCU_IP_SEL.h */
	#include "HT8_Simulation_UART.h"
#endif

u8 Rx_Buff[DATA_NUM];	//I2C receive buff
u8 Rx_Data[DATA_NUM];	//I2C receive data
u8 Rd_CheckSum;			//I2C checksum
u8 Rd_Wr_Flag;			//I2C read and write flag,0:write; 1:read

/**
  * @brief I2C master main entry point.
  * @par Parameters:
  * None
  * @retval 
  * None
  */
void main()
{
	u8 i;
	Rd_Wr_Flag = 0;

#ifdef	DEBUG
/* Debug mode can be enabled by uncommenting "DEBUG" Macro in HT8_MCU_IP_SEL.h */
	SIMULATION_UART_INIT();
#endif
	
	for (i=0;i<DATA_NUM;i++)
	{
		Rx_Buff[i] = 0;			//clear receive buff
	}
	i = 0;
	Tx_Buff[0] = 0x55;			//transmit byte1
	Tx_Buff[1] = 0xAA;			//transmit byte2
	Tx_Buff[2] = 0xCC;			//transmit byte3
	
	/* initialization I2C master function(software simulation) */
	I2C_Master_Init();
	
	TimeBase_Init();			//timebase initialization,
	TB_ENABLE();				//enable timebase
	
	GCC_DELAY(2000);			//wait system stable
	
	//system loop
	while(1)
	{

		if (1 == TB0_FLAG())		//timebase 0 counter overflow,128ms 
		{
			TB0_CLEAR_FLAG();
			
			if (0 == Rd_Wr_Flag)	
			{
				I2C_Write();		//write data to slave
				Rd_Wr_Flag = 1;		//set Rd_Wr_Flag,next is receive I2C data
			}
			
			else 					//read data from slave
			{
				I2C_Read(Rx_Buff,sizeof(Rx_Buff)/sizeof(Rx_Buff[0]));  //I2C receive data
				GCC_CLRWDT();	
				Rd_CheckSum = Rx_Buff[0] + Rx_Buff[1] + Rx_Buff[2];			//calculate Rd_CheckSum
				GCC_NOP();
				
				if( (Rd_CheckSum == Rx_Buff[3]))	//Rd_CheckSum is OK
				{
				#ifdef	DEBUG	
				/* Send I2C receive data to PC for debug,Debug mode can be enabled 
				   by uncommenting "DEBUG" Macro in HT8_MCU_IP_SEL.h */	
					UART_SoftWareSendByte(Rx_Buff[0]);			//send I2C receive data to PC by uart
					UART_SoftWareSendByte(Rx_Buff[1]);			//send I2C receive data to PC by uart
					UART_SoftWareSendByte(Rx_Buff[2]);			//send I2C receive data to PC by uart
				#endif	
					Rd_CheckSum = 0;
					Rx_Data[0] = Rx_Buff[0];		//
					Rx_Data[1] = Rx_Buff[1];		// 
					Rx_Data[2] = Rx_Buff[2]; 		//
					Rx_Data[3] = Rx_Buff[3];    	//
					for (i=0; i<DATA_NUM; i++)
					{
						Rx_Buff[i] = 0;				//clear receive buff
					}
					GCC_DELAY(1);
				}
				else							//CheckSum error
				{
					GCC_NOP();
					/* user define,such as set a checksum error flag */
				}
				Rd_Wr_Flag = 0;		//clear Rd_Wr_Flag,next time is transmit I2C data
			}		
		}
		GCC_CLRWDT();
	}
	
}


/******************* (C) COPYRIGHT 2018 Holtek Semiconductor Inc *****END OF FILE****/