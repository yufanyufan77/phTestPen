#include "rb3xpxx5a.h"
#include  "tds.h"

xdata unsigned int  utAdjData;
xdata unsigned char AdjData[2];




const unsigned int code TdsAdjTable[108] =
{
    0x00,  0x00, 0x6d,  0x6c, 0xd8,  0x6d,
    0x141, 0x6e, 0x1a8, 0x6f, 0x20d, 0x70,
    0x271, 0x71, 0x2d3, 0x72, 0x333, 0x73,
    0x391, 0x74, 0x3ee, 0x75, 0x449, 0x76,
    0x4a3, 0x77, 0x4fb, 0x78, 0x552, 0x79,
    0x5a7, 0x7a, 0x5fb, 0x7b, 0x64e, 0x7c,
    0x69f, 0x7d, 0x6ef, 0x7e, 0x73e, 0x7f,
    0x78c, 0x80, 0x7d8, 0x81, 0x823, 0x82,
    0x86d, 0x83, 0x8b6, 0x84, 0x8fe, 0x85,
    0x944, 0x86, 0x98a, 0x87, 0x9cf, 0x88,
    0xa12, 0x89, 0xa55, 0x8a, 0xa97, 0x8b,
    0xad7, 0x8c, 0xb17, 0x8d, 0xbf4, 0x8e,
    0xb94, 0x8f, 0xbd1, 0x90, 0xc0e, 0x91,
    0xc49, 0x92, 0xc84, 0x93, 0xcbe, 0x94,
    0xcf7, 0x95, 0xd2f, 0x96, 0xd67, 0x97,
    0xd9e, 0x98, 0xdd4, 0x99, 0xe09, 0x9a,
    0xe3e, 0x9b, 0xe72, 0x9c, 0xea6, 0x9d,
    0xed5, 0x9e, 0xf0b, 0x9f, 0xffc, 0x100
};

////unsigned int AveCal(unsigned int *adr, unsigned char len)
////{
////    xdata unsigned char i;
////    xdata unsigned int *p;
////    xdata unsigned int sum;

////    p = adr;
////    sum = 0;
////    for(i = 0; i < len; i++)
////    {
////        sum += *(p + i);
////    }
////    sum /= len;
////    return sum;
////}

unsigned int TDSCal(unsigned int TDSAdVal, unsigned int wendu)
{
    xdata unsigned long result;
    xdata unsigned long tmp, tmp2;
    tmp = (unsigned long)TDSAdVal;
    tmp2 = (unsigned long)wendu;
//    tmp2 = 250;
    result = (tmp * 1000) / (1024 - tmp);
    if(wendu > 250)
    {
        result = result * (1000 - (tmp2 - 250) * 2) / 1000;
    }
    else
    {
        result = result * (1000 + (250 - tmp2) * 2) / 1000;
    }

    tmp = (unsigned long)utAdjData;
    result *= tmp;

    return ((unsigned int)(result >> 8));
}

unsigned int TdsAdj(unsigned int TdsVal)
{
    xdata unsigned char i, j;
    xdata unsigned long Val;
    xdata unsigned int chengshu;

    i = 0;
    j = 0;
    for(i = 0; i < 106; i++) 														  //��������
    {
        if((TdsAdjTable[i] <= TdsVal) && (TdsVal < TdsAdjTable[i + 2]))
        {
            chengshu = TdsAdjTable[i + 3];
            break;
        }
        else
            chengshu = 0xc2;
    }
    Val = (unsigned long)(TdsVal) * (unsigned long)(chengshu);
    Val = Val >> 8;
    return (unsigned int)Val;

}
int temp_showdata(void)
{
    int volue;
    if(NTCAVE < 1000)
    {
        volue = 250 + (1000 - NTCAVE) * 18 / 100 + (10000 / NTCAVE - 10) * 9 + 5;
    }
    else if(NTCAVE > 1000)
    {
        volue = 250 - (NTCAVE - 1000) * 18 / 100 ;

    }
    else
    {
        volue = 250;
    }
    return volue;
}
