#include "rb3xpxx5a.h"
#include <intrins.h>
#include "def.h"
#include "EE.h"



//unsigned char EEPROM_read(unsigned char Addr) 
//{ 
//	unsigned char EEData; 
//	_bp=1;
//	_eea = Addr;
//	
//	_mp1 = 0x40;	

//	
//	_emi = 0;	// Disable interrupt	
//	
//	iar1_1 = 1;	// read enable
//	iar1_0 = 1;	// read data
//	
//	_emi = 1; 	// Enable interrupt
//	
//	while(iar1_0)
//	{ 
//		_clrwdt(); 
//		_clrwdt1();
//		_clrwdt2();
//	} 
//	
//	EEData=_eed; 
//	_iar1 = 0;	
//	_bp=0;
//	return EEData; 
//} 

//void EEPROM_write(unsigned char Addr,unsigned char Data) 
//{ 
//	
//	_eea = Addr; 
//	_eed = Data; 
//	_bp=1;
//	_mp1 = 0x40;	
// 
//	
//	_emi = 0;	// Disable interrupt
//	
//	iar1_3 = 1;	// Write enable
//	iar1_2 = 1;	// Write data
//	
//	_emi = 1;	// Enable interrupt
//	
//	while(iar1_2) 
//	{ 
//		_clrwdt(); 
//		_clrwdt1();
//		_clrwdt2();
//	} 
//	
//	_iar1 = 0; 
//	_bp=0;
//} 



#define SetSCL()	 (P5 |= 0X02)
#define ClrSCL()	 (P5 &= 0XFD)
#define SetSDA()	 (P5 |= 0X01)
#define ClrSDA()	 (P5 &= 0XFE)


void delay(unsigned char t)
{
	for(;t>0;t--)
	{;}
	
}

/*
**********************************************************
*�� �� ����SDA_out
*����������SDA����������
*��    �룺��
*��    ������
**********************************************************
*/
void SDA_out(void)
{
    P5DPL = 0xAa;	   //0010 1000			0100     P20 P21 -sda  11001111  
}

/*
**********************************************************
*�� �� ����SDA_in
*����������SDA�����������
*��    �룺��
*��    ������
**********************************************************
*/
void SDA_in(void)
{
    P5DPL = 0xA9;
}

//==================================================
//I2C START
void I2CStart(void)
{
	SDA_out();
	SetSDA();			//SDA=1
	SetSCL();			//SCL=1
  _nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	ClrSDA();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	ClrSCL();
}

//I2C STOP
void I2CStop(void)
{
	ClrSDA();			//ֹͣ�����ӳ���
	_nop_();
	_nop_();
	ClrSCL();
	
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	SetSCL();
	
	_nop_();
	_nop_();
	_nop_();
	SetSDA();
	_nop_();
	_nop_();
	_nop_();
	
}

unsigned char I2C_Wait_Ack() 
{
	unsigned char i=0;
	SDA_in();
	SetSCL();
	_nop_();
	while(P5&0X01==1)
	{
		i++;
		if(i>4)
		{
			I2CStop();
			return 0;//Ӧ��ʱ
		}
	}	  
	ClrSCL();
	_nop_();
	SDA_out();	
	return 1;
}

void I2C_Ack(void)
{
	ClrSDA();
	SDA_out();	
	_nop_();
	_nop_();
	SetSCL();
	_nop_();
	_nop_();	
	ClrSCL();
	_nop_();
	_nop_();
}

void I2C_NAck(void)
{
  SetSDA();
	SDA_out();	
	_nop_();
	_nop_();
	SetSCL();
	_nop_();
	_nop_();	
	ClrSCL();
	_nop_();
	_nop_();
}

//Send byte
unsigned char I2C_Send_Byte(unsigned char SData)
{
	unsigned char i;
	for(i=0;i<8;i++)
	{
		((SData & 0x80)==0x80)?SetSDA():ClrSDA();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		SetSCL();	  	//SCL=1
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		SData <<= 1;
  	ClrSCL();	  	//SCL=0	
		_nop_();
		_nop_();
	}
	_nop_();
	_nop_();

	if(I2C_Wait_Ack())
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

//Receive byte
unsigned char I2C_Read_Byte(unsigned char ack)
{
	unsigned char i;
 	unsigned char RData;
	
	RData = 0x00;
	SDA_in();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	for(i=0;i<8;i++)
	{
		SetSCL();	  	//SCL=1
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
  	RData <<= 1;
  	RData |= (P5 & 0X01);
  	ClrSCL();	 	//SCL=0
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	};
	if(ack)
	  I2C_Ack();
	else
	  I2C_NAck();
	
	return(RData);
}

/*
**********************************************************
*�� �� ����P24C02A_ByteWrite
*������������ĳ����ַдһ����
*��    �룺��ַ������
*��    ������
**********************************************************
*/
void P24C02A_ByteWrite(unsigned char addr,unsigned char byte)
{
	I2CStart();
  I2C_Send_Byte(DEVICE_ADDR_WRITE);
//	I2C_Send_Byte(0x00);
  I2C_Send_Byte(addr);	   
  I2C_Send_Byte(byte);
  I2CStop();
	
	delay(200);  //��ʱ5ms
	delay(200);
	delay(200);
	delay(200);
	delay(200);

}

/*
**********************************************************
*�� �� ����P24C02A_PageWrite
*�����������������ַ��ʼд�������
*��    �룺��ַ������
*��    ������
**********************************************************
*/
//void P24C02A_PageWrite(unsigned char addr,unsigned char num,unsigned char *buff)
//{
//	unsigned char i;
//	I2CStart();
//  I2C_Send_Byte(DEVICE_ADDR_WRITE);
//  I2C_Send_Byte(addr);	
//	
//	for(i=0;i<num;i++)
//	{
//    I2C_Send_Byte(buff[i]);
//	}
//  I2CStop();
//	
//	delay(100);      //��ʱ5ms
//	delay(100);
//	delay(100);
//	delay(100);
//	delay(100);
//}

/*
**********************************************************
*�� �� ����P24C02A_RandomRead
*������������ָ����ַ�е�����
*��    �룺��ַ
*��    ��������
**********************************************************
*/
unsigned char P24C02A_RandomRead(unsigned char addr)
{
	unsigned char temp;
	I2CStart();
	I2C_Send_Byte(DEVICE_ADDR_WRITE);
//	I2C_Send_Byte(0x00);
	I2C_Send_Byte(addr);
	I2CStart();
	I2C_Send_Byte(DEVICE_ADDR_READ);
	temp = I2C_Read_Byte(0);
	I2CStop();
	return temp;
}

/*
**********************************************************
*�� �� ����P24C02_SequentialRead
*������������ָ����ַ��ʼ��ȡ�������
*��    �룺��ַ
*��    ��������
**********************************************************
*/
//void P24C02_SequentialRead(unsigned char addr,unsigned char num,unsigned char *buff)
//{
//	unsigned char i;
//  I2CStart();
//	I2C_Send_Byte(DEVICE_ADDR_WRITE);
//	I2C_Send_Byte(addr);
//	I2CStart();
//	I2C_Send_Byte(DEVICE_ADDR_READ);
//	for(i=0;i<(num-1);i++)
//	  buff[i] = I2C_Read_Byte(1);
//	buff[i]=I2C_Read_Byte(0);
//	I2CStop();
//}
