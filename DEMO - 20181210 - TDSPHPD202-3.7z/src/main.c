/*========================================================================================
option:
HIRC--16MHz@Vdd=5V
Others select by user
========================================================================================*/
#include "rb3xpxx5a.h"
#include	"def.h"
#include	"app.h"
#include	"EE.h"
#include  "tds.h"
static bit hold_flag = 0;
static bit cf_flag = 0; //0 c 1 f
static bit dig_flag = 1; //С���� ��1 ��0
static bit d2_flag = 1;
static unsigned char TDS_Mode = 0;
static xdata int  TDSAVE_HOLD = 0, NTCAVE_HOLD = 0, ECSAVE_HOLD = 0, adcvalue_ave_HOLD = 0;

extern xdata unsigned int  utAdjData;
extern xdata unsigned char AdjData[2];
extern bit ADC_flag ;

typedef struct phParm
{
    unsigned char init ;  //��ȵ�ѹ
    unsigned char init1 ;  //��ȵ�ѹ
    unsigned char phK_4V ;//��ȵ�ѹ
    unsigned char phK_9V ;//��ȵ�ѹ
    unsigned char phK_6V ;//���Ե�ѹ
} phParm_Type;
phParm_Type phParm;
extern unsigned char key, key_state;
unsigned char code Trans_Segment[19] = {0xaf, 0xa0, 0xcb, 0xe9, 0xe4,
                                        0x6d, 0x6f, 0xa8, 0xef, 0xed,
                                        0x00, 0xEE/*A 11*/, 0xE3/*d 12*/, 0x4F/*E 13*/, 0xe6/*H 14*/, 0x07/*L 15*/, 0X62 /*n 16*/, 0x42/*r 17*/, 0X40 /*- 18*/
                                       };
unsigned char Dis_Buffer[5], Digit[7];
unsigned short Phase_Count, Sec_Counter;
unsigned short Sec_sleep = 0;//����˯�߿��ƺ͵��������
unsigned char FG_HalfSec;
int adcval = 0;
u16 temp = 0;
u16 temp1 = 0;
float tempVol = 0;
unsigned char page = 0;
static unsigned int keydelay = 0;
static unsigned char waitTime = 99;
static unsigned char shark = 0;
static unsigned char flag = 0;
static unsigned int Stability = 0;
static unsigned char shakeled = 125;
static unsigned char cut = 0;

extern xdata unsigned char AdjData[2];
extern unsigned char adc_click;

void  dis(unsigned short showvolue);

/*
**********************************************************
*�� �� ����wdt_reloadcnt
*����������ι��
*��    �룺��
*��    ������
**********************************************************
*/
void wdt_reloadcnt(void)
{
    WDTEN0 = 0;
    WDTEN1 = 0;
    WDTEN0 = 0x39;
    WDTEN1 = 0xC6;
}
/*
********************************************************************************
*�� �� ����adc_isr  ������һЩ�����ٸ�������
*����������adc�жϴ�������
*��    �룺NEW_DATA �²���ֵ
       OLD_DATA �ϴ��˲����
       k        �˲�ϵ��(0~255)(�������˲�����е�Ȩ��)
*��    ���� �����˲����
********************************************************************************
*/
int filter(int NEW_DATA, int OLD_DATA, char k)
{
    int result;
    if(NEW_DATA < OLD_DATA)
    {
        result = OLD_DATA - NEW_DATA;
        result = result * k;
        result = result + 128; //+128��Ϊ����ɫ����
        result = result / 256; //����256
        result = OLD_DATA - result;
    }
    else if(NEW_DATA > OLD_DATA)
    {
        result = NEW_DATA - OLD_DATA;
        result = result * k;
        result = result + 128; //+128��Ϊ����ɫ����
        result = result / 256; //����256
        result = OLD_DATA + result;
    }
    else result = OLD_DATA;
    return(result);
}


//��ȡ����
void readPHParm(void)
{
    phParm.init = P24C02A_RandomRead(0x00);
    phParm.init1 = P24C02A_RandomRead(0x10);
    if((phParm.init != 0x5A)  || (phParm.init1 != 0X5A))
    {
        P24C02A_ByteWrite(0x00, 0x5A);
        P24C02A_ByteWrite(0x01, 150);
        P24C02A_ByteWrite(0x02, 123);
        P24C02A_ByteWrite(0x03, 100);
        P24C02A_ByteWrite(0x04, 0x60);
        P24C02A_ByteWrite(0x05, 0x01);
        P24C02A_ByteWrite(0x10, 0X5A);
    }
    phParm.phK_4V = P24C02A_RandomRead(0x01);
    phParm.phK_6V = P24C02A_RandomRead(0x02);
    phParm.phK_9V = P24C02A_RandomRead(0x03);
    AdjData[0] = P24C02A_RandomRead(0x04);
    AdjData[1] = P24C02A_RandomRead(0x05);

    utAdjData = AdjData[1];
    utAdjData <<= 8;
    utAdjData |= AdjData[0];
    //    phParm.phK_4V = 150;
    //    phParm.phK_6V = 123;
    //    phParm.phK_9V = 100;
}

void clearDisBuff(void)
{
    unsigned char i;
    for(i = 0; i < 5; i++) Dis_Buffer[i] = 0;		//Clear Buffer
    for(i = 0; i < 4; i++) Digit[i] = 0;
    //	Dis_Buffer[1]|=0b00010000; 					//С���㴦��
    Phase_Count = 0;
    FG_HalfSec = 0;
    Sec_Counter = 125;						//125*4ms=0.5 Second
    //	_frame=0;  �ر���ʾ
}

void sys_init(void)
{
    Sec_sleep = 0;
    P24 = 0;
    P0DPH = 0xA0;
    P2DPH = 0xaa;
    P2DPL = 0xaa;
    P12 = 0;
    P1DPL |= 0X20;//����P1.2Ϊ���������
    P5DPL = 0XAA;
    P5DPH = 0XAA;
    P6DPL = 0XAA;
    ckds_config(mclk_div1);
    ledInit();
    InitLCD();
    ADInit();
    timer_Init();
    initWup();


    clearDisBuff();
    ledOn();
    readPHParm();
    page = 0;
}


//�ȴ���ѹ�ȶ�
unsigned char WaitingVoltageStability(u16 voltage)
{
    static u16 volTemp = 0;
    static unsigned short pageback = 0;

    volTemp = voltage;

    if(pageback != page)
    {
        Stability = 0;
        pageback = page;
        waitTime = 99;

    }
    if(waitTime > 70)
        waitTime = 0;
    if(waitTime % 2 == 0)
    {
        if((volTemp + 2) >= voltage && volTemp <= (2 + voltage))
        {
            Stability++;
        }
    }
    if(Stability > 9)
        return 1;
    if(waitTime > 30)
    {
        waitTime = 99;
        if(!((volTemp + 2) >= voltage && volTemp <= (2 + voltage)))
        {
            page = 4;
            return 0;
        }
    }
    return 0;
}




//��ѹ��ʾ

void  disVol(void)
{
    temp1 = tempVol * 100;
    if((temp1 < (phParm.phK_4V - 1) && temp1 >= (phParm.phK_6V + 1)) || temp1 >= (phParm.phK_4V + 1)) //���
    {
        adcval = 686 - (285 / (phParm.phK_4V - phParm.phK_6V )) * (temp1 - phParm.phK_6V);
    }
    if(temp1 < (phParm.phK_6V + 1) && temp1 >= (phParm.phK_6V - 1))
    {
        adcval = 686;
    }
    if((temp1 < phParm.phK_4V + 1) && temp1 >= (phParm.phK_4V - 1))
    {
        adcval = 401;
    }
    if((temp1 < phParm.phK_9V + 1) && temp1 >= (phParm.phK_9V - 1))
    {
        adcval = 918;
    }
    if((temp1 < (phParm.phK_6V - 1) && temp1 >= (phParm.phK_9V + 1)) || temp1 < (phParm.phK_9V - 1))
    {
        adcval = 686 + (232 / (phParm.phK_6V - phParm.phK_9V )) * (phParm.phK_6V - temp1);
    }
    //    adcval = temp1;
    if(adcval > 1400)
    {
        Digit[0] = 14;
        Digit[1] = 18;
        Digit[2] = 18;
        Digit[3] = 18;
        dig_flag = 0;
    }
    else if(adcval < 0)
    {
        Digit[0] = 15;
        Digit[1] = 18;
        Digit[2] = 18;
        Digit[3] = 18;
        dig_flag = 0;
    }
    else
    {
        dis(adcval);
    }
    //Convert to Segment Data
    if(Digit[0] == 0 && adcval < 1401)
        Digit[0] = 10;
}

//У׼
void verifyVal(void)
{
    //clearDisBuff();
    sleep = 0;
    tempVol = adcvalue_ave;
    tempVol = tempVol * 1.984 / 4096.00;
    temp = tempVol * 100;

    if(WaitingVoltageStability(temp))
    {
        if(page == 2) //�궨���
        {
            if(temp >= 130 && temp < 175)
            {
                LCDM16 &= 0X0B; //���CAL
                phParm.phK_4V = temp;
                P24C02A_ByteWrite(0x01, phParm.phK_4V);
                flag = 2;
                Stability = 0;
            }
            else
                page = 4;
        }
        else if(page == 1) //�궨���Զ�
        {
            if(temp >= 105 && temp < 130)
            {
                LCDM16 &= 0X0B; //���CAL
                phParm.phK_6V = temp;
                P24C02A_ByteWrite(0x02, phParm.phK_6V);
                flag = 1;
                Stability = 0;
            }
            else
                page = 4;
        }
        else if(page == 3) //�궨���
        {
            if(temp < 105 && temp > 75)
            {
                LCDM16 &= 0X0B; //���CAL
                phParm.phK_9V = temp;
                P24C02A_ByteWrite(0x03, phParm.phK_9V);
                flag = 3;
                Stability = 0;
            }
            else
                page = 4;
        }
        if(page == 4)
        {
            cut = 0;
            flag = 0;
            Stability = 0;
            LCDM16 &= 0X0B; //���CAL
            return;
        }
        if(page == 1)
        {
            page = 0;
            dis(618);
        }
        else if(page == 2)
        {
            page = 0;
            dis(401);
        }
        else if(page == 3)
        {
            page = 0;
            dis(918);
        }
        else
        {
            cut = 0;
            page = 4;
        }
        return;

    }
}

/*
**********************************************************
*�� �� ����void  dis(unsigned int showvolue)
*������������ֵת����ʾֵ
*��    �룺showvolue
*��    ������
**********************************************************
*/
void  dis(unsigned int showvolue)
{
    int volue;
    if(showvolue != 0)
    {
        FG_HalfSec = 0;
        volue = showvolue;
        Digit[0] = volue / 1000;
        Digit[1] = (volue / 100) % 10;	   	//Convert to Segment Data
        Digit[2] = (volue / 10) % 10;
        Digit[3] = volue % 10;			//Convert to Segment Data
        if(Digit[0] == 0)
        {
            if(page < 10)
            {
                Digit[0] = 10;
            }
            else
            {
                Digit[0] = 0;
            }
        }
        if(page < 10)
            dig_flag = 1;
        else
            dig_flag = 0;
    }
    else
    {
        //			if(page < 10)
        //			{
        ////        Digit[0] = 15;
        ////        Digit[1] = 18;
        ////        Digit[2] = 18;
        ////        Digit[3] = 18;
        ////        dig_flag = 0;
        //			}
        if(page >= 10)
        {
            Digit[0] = 0;
            Digit[1] = 0;
            Digit[2] = 0;
            Digit[3] = 0;
            dig_flag = 0;
        }
    }

}


void dis_temp( int wendu)
{


    if(wendu < 0)
    {
        Digit[4] = 10;
        Digit[5] = 10;
        Digit[6] = 15;
        d2_flag = 0;
    }
    else if(wendu > 600)
    {
        Digit[4] = 10;
        Digit[5] = 10;
        Digit[6] = 14;
        d2_flag = 0;
    }
    else
    {
        if(cf_flag)  //F
        {
            wendu =  wendu * 9 / 5 + 320;
        }
        Digit[4] = wendu / 100;
        if(Digit[4] == 0)
        {
            Digit[4] = 10;
        }
        Digit[5] = (wendu / 10 ) % 10;
        Digit[6] = wendu % 10;
        d2_flag = 1;
        //			Digit[7] = NTCAVE  % 10;
    }

}
/*
**********************************************************
*�� �� ����dis_state
*����������״̬
*��    �룺shownum
*��    ������
**********************************************************
*/
void dis_state(unsigned char shownum)
{
    Digit[0] = 10;
    if(shownum == 1)  //SA
    {
        Digit[1] = 10;	   	//Convert to Segment Data
        Digit[2] = 5;
        Digit[3] = 11;			//Convert to Segment Data

    }
    else if(shownum == 2) //End
    {
        Digit[1] = 13;	   	//Convert to Segment Data
        Digit[2] = 16;
        Digit[3] = 12;			//Convert to Segment Data
    }
    else if(shownum == 3) //Err
    {
        Digit[1] = 13;	   	//Convert to Segment Data
        Digit[2] = 17;
        Digit[3] = 17;			//Convert to Segment Data

    }

    dig_flag = 0;
}

/*
**********************************************************
*�� �� ����void display_lcd(void)
*������������ʾ��LCD
*��    �룺��
*��    ������
**********************************************************
*/
void display_lcd(void)
{

    if(((TKCON & 0x10) == 0x00) && (TDS_Mode > 0))
    {
        LCDM15 = 0;
        LCDM14 = 0;
        LCDM13 = 0;
        LCDM12 = 0;
        LCDM11 = 0;
        LCDM10 = 0;
        LCDM9 = 0;
        LCDM8 = 0;
    }
    else
    {
        LCDM15 = Trans_Segment[Digit[3]] >> 4;
        LCDM14 = Trans_Segment[Digit[3]] & 0x0f;
        LCDM13 = Trans_Segment[Digit[2]] >> 4;
        LCDM12 = Trans_Segment[Digit[2]] & 0x0f;
        LCDM11 = (Trans_Segment[Digit[1]] >> 4) | dig_flag;
        LCDM10 = Trans_Segment[Digit[1]] & 0x0f;
        LCDM9 = Trans_Segment[Digit[0]] >> 4;
        LCDM8 = Trans_Segment[Digit[0]] & 0x0f;
    }

    LCDM3 = Trans_Segment[Digit[4]] >> 4;
    LCDM2 = Trans_Segment[Digit[4]] & 0x0f;
    LCDM5 = Trans_Segment[Digit[5]] >> 4 | d2_flag;
    LCDM4 = Trans_Segment[Digit[5]] & 0x0f;
    LCDM17 = (Trans_Segment[Digit[6]] >> 4);
    LCDM19 = Trans_Segment[Digit[6]] & 0x0f;
    if(page < 10)	 //PH
    {
        LCDM0 = 0x08;
        LCDM16 &= 0X0c;
    }
    else if(page < 20) //TDS
    {
        if(TDS_Mode == 0)
        {
            LCDM0 = 0X04;
        }
        LCDM16 = 0X01;
    }
    else  //EC
    {
        LCDM0 = 0x02;
        LCDM16 = 0X02;
    }
    if((page % 10 == 0) && (TDS_Mode == 0))
    {
        LCDM1 = 0X03;  //ATC MEMAS
    }
    else
    {
        LCDM1 = 0X01;  //ATC MEMAS
    }
    if(cf_flag)  //F���϶�
    {
        LCDM1 &= 0X0b;
        LCDM17 |= 0X01;
    }
    else          //C ���϶�
    {
        LCDM1 |= 0X04;
        LCDM17 &= 0X0e;
    }
    if(hold_flag)
    {
        LCDM16 |= 0x08;
    }

}

/*
**********************************************************
*�� �� ����void PH_PAGE_VP(page_num)
*����������PHУ׼����
*��    �룺page_num
*��    ������
**********************************************************
*/
void PH_PAGE_VP(page_num)
{
    static unsigned char time_num = 0;
    if(FG_HalfSec && P16)
    {
        FG_HalfSec = 0;
        if(time_num < 7)
        {
            time_num++;

            if (time_num > 6)  //SA
            {

                dis_state(1);
            }
            else if(time_num > 2)
            {
                if(page_num == 1)
                    dis(686);
                else if(page_num == 2)
                    dis(401);
                else
                    dis(918);
            }
        }
        else
        {
            if(flag != page_num)
            {
                verifyVal();
            }
            if(flag == page_num)  //У׼�ú���ʱ�����
            {
                time_num = 0;
                dis_state(2);

            }
            if(page == 4)
            {
                time_num = 0;
            }
        }
    }
}

/*
**********************************************************
*�� �� ����tds_cal_finish
*����������tds�Զ�У׼���
*��    �룺��
*��    ������
**********************************************************
*/
void TDS_cal_finish(void)
{
    AdjData[0] = (unsigned char)(utAdjData);
    AdjData[1] = (unsigned char)(utAdjData >> 8);
    P24C02A_ByteWrite(0x04, AdjData[0]);
    P24C02A_ByteWrite(0x05, AdjData[1]);
    TDS_Mode = 0;
    TKCON = 0;
}

/*
**********************************************************
*�� �� ����tds_auto_cal
*����������tds�Զ�У׼
*��    �룺��
*��    ������
**********************************************************
*/
void TDS_auto_cal(void)
{
    if(TDS_Mode == 1)
    {
        if(P16)
        {
            if(ADC_flag)
            {
                ADC_flag = 0;
                if(TDSAVE  > 503)
                {
                    utAdjData --;

                }
                else if(TDSAVE < 497)
                {
                    utAdjData ++;

                }
                else
                {

                    TDS_cal_finish( );
                }
            }

        }
    }
}
/*
**********************************************************
*�� �� ����void pageprocess(void)
*�����������˵�������
*��    �룺��
*��    ������
**********************************************************
*/
void pageprocess(void)
{
    static int PH_old_num = 0, NTC_old_num = 0, TDS_old_num = 0;
    int add_num, sub_num;
    int wendu_C;
    switch(page)
    {
    case 0:  //PH
        if((ADCON >> 4) == 2)  //��һ״̬ΪTDS
        {
            adc_click = 0;
            ADCON = 0x18;  //PHͨ��
        }
        if(FG_HalfSec && ADC_flag)
        {
            FG_HalfSec = 0;
            ADC_flag = 0;
            flag = 0;
            Stability = 0;					//Clear Half Second Flag
            add_num = PH_old_num + 20;
            sub_num = PH_old_num - 20;
            if((adcvalue_ave < sub_num) || (adcvalue_ave > add_num))
            {
                PH_old_num = adcvalue_ave;
            }
            add_num = PH_old_num + 10;
            sub_num = PH_old_num - 10;
            if((NTCAVE < sub_num) || (NTCAVE > add_num))
            {
                NTC_old_num = NTCAVE;
            }
            //            if(NTC_old_num == 0)
            //            {
            //                NTC_old_num = NTCAVE;
            //            }
            NTCAVE = filter(NTCAVE, NTC_old_num, 50);
            tempVol =  filter(adcvalue_ave, PH_old_num, 50);
            tempVol = tempVol * 1.984 / 4096.00;//tempVol * 2.325 / 4096.00; 2.325*2048/2400
            wendu_C = temp_showdata();
            dis_temp(wendu_C-30);
            disVol();
            /*dis(phParm.phK_6V);*/
        }
        break;
    case 1:
        PH_PAGE_VP(1);
        break;
    case 2:
        PH_PAGE_VP(2);

        break;
    case 3:
        PH_PAGE_VP(3);

        break;
    case 20:
    case 10:   //TDS
        if((ADCON >> 4) == 1)   //�Ƿ��ǲɼ�TDS��ͨ�� ��һ״̬��PH
        {
            adc_click = 0;
            ADCON = 0x28;//0x28 TDS�ɼ�ͨ��
        }
        if(FG_HalfSec && ADC_flag)
        {
            FG_HalfSec = 0;
            ADC_flag = 0;
            add_num = PH_old_num + 10;
            sub_num = PH_old_num - 10;
            if((NTCAVE < sub_num) || (NTCAVE > add_num))
            {
                NTC_old_num = NTCAVE;
            }
            //            if(NTC_old_num == 0)
            //            {
            //                NTC_old_num = NTCAVE;
            //            }
            NTCAVE = filter(NTCAVE, NTC_old_num, 50);
            wendu_C = temp_showdata();
            add_num = TDS_old_num + 20;
            sub_num = TDS_old_num - 20;
            if((TDSAVE < sub_num) || (TDSAVE > add_num))
            {
                TDS_old_num = TDSAVE;
            }
            TDSAVE = filter(TDSAVE, TDS_old_num, 50);
            TDSAVE = TDSCal(TDSAVE, wendu_C);
            TDSAVE = TdsAdj(TDSAVE);
            dis_temp(wendu_C-30);
            if(page == 10)
            {
                dis(TDSAVE);
                TDS_auto_cal();
            }
            else  // ==20  EC
            {
                ECSAVE = TDSAVE << 1;
                dis(ECSAVE);
            }

        }
        break;
    case 4:
        if(FG_HalfSec) //err
        {
            Stability = 0;
            cut ++;
            FG_HalfSec = 0;
            dis_state(3);

        }
        if(cut > 4)
        {
            cut = 0;
            page = 0;
        }
    }
    display_lcd();

}

/*
**********************************************************
*�� �� ����keyprocess
*��������������ɨ���ֵ
*��    �룺��
*��    ������
**********************************************************
*/
void keyprocess(void)
{
    if(key_state)  //����ɨ�����
    {
        keydelay ++;
        if(key_state == STATE_HOLD)
        {
            if(sleep < 600)
            {
                if(keydelay >= 750)
                {
                    key = KEY_SWCH_TMP_UNIT;
                    key_state = 0;
                    keydelay = 0;
                }
                if(P15 && (keydelay > 4))
                {
                    key = KEY_HOLD;
                    key_state = 0;
                    keydelay = 0;
                }
            }
            else
            {
                key = 0;
                key_state = 0;
                keydelay = 0;
            }
        }
        else if(key_state == STATE_CAL)
        {
            if(sleep < 600)
            {
                if(keydelay == 750 )
                {
                    key = KEY_CALI_AUTO;
                }
                else if(keydelay > 2500)
                {
                    key = KEY_CALI_MAN;
                    key_state = 0;
                    keydelay = 0;
                }
                if(P16)
                {
                    if((keydelay > 4) && (keydelay < 750))
                    {
                        key = KEY_CAL;
                    }
                    key_state = 0;
                    keydelay = 0;
                }
            }
            else
            {
                key = 0;
                key_state = 0;
                keydelay = 0;
            }
        }
        else
        {
            if(P17 == 0)
            {
                key = KEY_POWER_ONOFF;
            }
            else
            {
                key = 0;
            }
            key_state = 0;
            keydelay = 0;
        }
        if(key)
        {
            if(sleep < 600)
            {
                Sec_sleep = 0;
                ledOn();
            }
        }
        if((page % 10 ) || (TDS_Mode) || hold_flag)
        {
            if(hold_flag)
            {
                if((key != KEY_POWER_ONOFF) && (key != KEY_HOLD))
                {
                    key = 0;
                }
            }
            else if(key != KEY_POWER_ONOFF)
            {
                key = 0;
            }
        }
    }
    if(key)  //������������
    {
        if(key == KEY_CAL)  //PH TDS EC�л�
        {
            if(TDS_Mode == 2)
            {
                TDS_cal_finish( );
            }
            else if((page % 10) == 0x00)
            {
                page = page + 10;
                if(page > 20)
                    page = 0;
                if(page == 0)
                {
                    P24 = 0;
                    P12 = 1;
                }
                else
                {
                    P12 = 0;
                    P24 = 1;
                }
            }
        }
        else if(key == KEY_CALI_AUTO) //TDS �Զ� PH �Զ�
        {
            if(page == 0)  //PH �Զ�
            {
                LCDM16 |= 0X04;  //��ʾCAL
                if(adcvalue_ave > 2600)  //>1.3V  mid=1.2 ����
                {
                    page = 2;
                }
                else if(adcvalue_ave < 2200) //<1.1V  ����
                {
                    page = 3;
                }
                else   //����
                {
                    page = 1;
                }
            }
            else if (page == 10)
            {
                TDS_Mode = 1; //�Զ�
                TKADDR = 0x40;
                LCDM0 &= 0x0b;
                TKCON = 0x84;  //1HZ

            }
        }
        else if(key == KEY_CALI_MAN)
        {
            TKCON = 0x80;  //2HZ
            TDS_Mode = 2;
        }
        else if(key == KEY_HOLD)
        {
            if(TDS_Mode == 2)
            {
                utAdjData --;
            }
            else
            {
                if(hold_flag)
                {
                    LCDM16 &= 0x07;
                    hold_flag = 0;
                }
                else
                {
                    hold_flag = 1;
                    LCDM16 |= 0x08;
                    if(page < 10)
                    {
                        adcvalue_ave_HOLD = adcvalue_ave;
                    }
                    else
                    {
                        TDSAVE_HOLD = TDSAVE;
                    }
                    NTCAVE_HOLD = NTCAVE;
                    ADGO = 0;  //ֹͣ�ɼ�
                }
            }
        }
        else if(key == KEY_SWCH_TMP_UNIT)
        {
            cf_flag ^= 0x01;
        }
        else  //���ػ���
        {
            if(TDS_Mode == 2)
            {
                utAdjData ++;
            }
            else
            {
                if(sleep >= 600)  //����Ѿ������������Ƴ�����
                {
                    sleep = 0;
                    Sec_sleep = 0;
                    ledOn();

                }
                else
                {
                    sleep = 600;
                }
            }
        }
        key = 0;
    }
    if(sleep >= 600)
    {
        TDS_Mode = 0;
        TKCON  =  0x00;
        if(page < 10)
            page = 0;
        enterSleep();
    }
}

/*
**********************************************************
*�� �� ����main
*����������������
*��    �룺��
*��    ������
**********************************************************
*/
void main(void)
{
    sys_init();
    wdt_reloadcnt();
    while(1)
    {
        if(sleep < 600)
        {
            pageprocess();
            if(Sec_sleep > 9)
            {
                ledOff();
            }
        }
    }
}

/*
**********************************************************
*�� �� ����tim0_isr
*������������ʱ���жϺ���
*��    �룺��
*��    ������
**********************************************************
*/
void tim0_isr() interrupt 1
{
    if(hold_flag == 0)
        ADGO = 1;
    wdt_reloadcnt();
    keyprocess();

    if(--Sec_Counter == 0)									//Reload Half Second Counter
    {

        Sec_sleep++;
        Sec_Counter = 125;
        /*		Sec_Counter=125;*/
        /*		FG_HalfSec=1;*/
        sleep ++;
        shark ++;
        if(waitTime < 100)
            waitTime ++;
    }

    if(--shakeled == 0)									//Reload Half Second Counter
    {
        shakeled = 125;
        /*		shakeled = 125;*/
        FG_HalfSec = 1;

    }

}