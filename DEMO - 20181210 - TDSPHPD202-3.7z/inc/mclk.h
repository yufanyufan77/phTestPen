/*
*********************************************************
*�� �� ����mclk.h
*����������mclk
*��    �ߣ�Bing.Zhang
*ʱ    �䣺2014.12.27
*��    ����V1.0.0
*********************************************************
*/
#ifndef _MCLK_H
#define _MCLK_H

#include"rb3xpxx5a.h"

typedef unsigned char u8;
typedef unsigned int  u16;

#define mclk_ihrc  0
#define mclk_ilrc  3
#define mclk_hcry  1
#define mclk_lcry  7
#define mclk_pll   2

#define mclk_div4  0
#define mclk_div2  1
#define mclk_div8  2
#define mclk_div1  3

extern void hcry_config(void);
extern void lcry_config(void);
extern void pll_config(void);
extern void mclk_set(u8 x);
extern void ckds_config(u8 x);

#endif