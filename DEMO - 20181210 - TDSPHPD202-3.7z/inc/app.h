#ifndef		APP_H
#define		APP_H

#include"rb3xpxx5a.h"

#define u16 unsigned int 
#define u8 unsigned char
	
#define mclk_div4  0
#define mclk_div2  1
#define mclk_div8  2
#define mclk_div1  3

#define LCD_SCAN_F1024  0X00
#define LCD_SCAN_F512   0X10
#define LCD_SCAN_F256   0X20
#define LCD_SCAN_F128   0X30

#define LCD_BIAS_3      0X04
#define LCD_BIAS_2      0X00

#define LCD_COM_1       0X00
#define LCD_COM_2       0X01
#define LCD_COM_3       0X02
#define LCD_COM_4       0X03

#define LCD_CRS_0       0X00
#define LCD_CRS_1       0X04
#define LCD_CRS_2       0X06
#define LCD_CRS_3       0X08
#define LCD_CRS_4       0X10
#define LCD_CRS_5       0X11
#define LCD_CRS_6       0X12
#define LCD_CRS_7       0X13

#define LCD_BRS_MIN     0X00
#define LCD_BRS_MID     0X01
#define LCD_BRS_MAX     0X03

#define KEY_POWER_ONOFF    0X01   //����ON/OFF �����ػ�
#define KEY_CAL            0X02   //����CAL �л�TDS PH
#define KEY_CALI_AUTO      0X03   //����3s �Զ�У׼
#define KEY_CALI_MAN       0X04   //����10s��TDS�ֶ�У׼
#define KEY_HOLD           0X05   //HOLD����
#define KEY_SWCH_TMP_UNIT  0X06   //HOLD����3s���л��¶�
#define STATE_ONOFF       0X01   //
#define STATE_CAL         0X02   //
#define STATE_HOLD        0X03   //

#define  ledInit() {P1DPH |= 0X02;P14=0;}
#define  ledOn()  P14=1
#define  ledOff() P14=0



extern int adcvalue_ave;
extern unsigned short Sec_sleep;//����˯�߿��ƺ͵��������

extern unsigned short sleep;
void ckds_config(u8 x);
//��ʼ��LCD
void InitLCD(void);
//AD��ʼ��
void ADInit(void);
//��ʱ����ʼ��
void timer_Init(void);
//����
void test(void);
//���������Ϊ0������ʾ  1����ʾ
void test1(void);

void delayms(unsigned short ms);	
//��ⰴ��
void checkKey(void);
//��������ģʽ
void enterSleep(void);
//void ledTogle(void);
void clearDisBuff(void);
//void ledopenClosed(void);	
void sys_init(void);
void clearScreem(void);
//У׼
void verifyVal(void);
//-----------------------------------
//Function: write data to EEPROM 
//----------------------------------- 
void PR_EEPROM_WR(unsigned char GU8V_EEPROM_ADDR,unsigned char GU8V_WR_DATA);
//-----------------------------------
//Function: read data from EEPROM
//----------------------------------- 
unsigned char PR_EEPROM_RD(unsigned char GU8V_EEPROM_ADDR);

void initWup(void);


#endif