/*
*********************************************************
*�� �� ����lcd.h
*����������lcd����ͷ�ļ�
*��    �ߣ�sirriam
*ʱ    �䣺2018.09.25
*��    ����V1.0.0
*********************************************************
*/
#ifndef _LCD_H
#define _LCD_H

#include "rb3xpxx5a.h"

#define LCD_SCAN_F1024  0X00
#define LCD_SCAN_F512   0X10
#define LCD_SCAN_F256   0X20
#define LCD_SCAN_F128   0X30

#define LCD_BIAS_3      0X04
#define LCD_BIAS_2      0X00

#define LCD_COM_1       0X00
#define LCD_COM_2       0X01
#define LCD_COM_3       0X02
#define LCD_COM_4       0X03

#define LCD_CRS_0       0X00
#define LCD_CRS_1       0X04
#define LCD_CRS_2       0X06
#define LCD_CRS_3       0X08
#define LCD_CRS_4       0X10
#define LCD_CRS_5       0X11
#define LCD_CRS_6       0X12
#define LCD_CRS_7       0X13

#define LCD_BRS_MIN     0X00
#define LCD_BRS_MID     0X01
#define LCD_BRS_MAX     0X03

extern void Lcd_Config(void);
#endif