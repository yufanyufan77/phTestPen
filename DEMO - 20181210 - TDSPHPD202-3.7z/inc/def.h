#ifndef		DEF_H
#define		DEF_H

#include "rb3xpxx5a.h"







#define		Col		0x80
#define		_C		0x80
#define		AM		0x80
#define		PM		0x80

//////////////////////////////////////////////////////////////////////////
typedef unsigned char __char;
typedef struct 
{
    unsigned char b0:1;
    unsigned char b1:1;
    unsigned char b2:1;
    unsigned char b3:1;
    unsigned char b4:1;
    unsigned char b5:1;
    unsigned char b6:1;
    unsigned char b7:1;  
    
} __8_bits;
typedef union 
{
    __8_bits bits;
    __char flag;
} __char_type;




extern		__char_type 		        fg_flag;	


#define 	GBV_EEPROM_DATAERR          fg_flag.bits.b0
#define 	GBV_EEPROMWR_DISABLE        fg_flag.bits.b1
#define 	GBV_EEPROMRD_DISABLE        fg_flag.bits.b2


         


#endif